# three.js (self-hosted copy)

- Version: 0.186.1 (revision 186), MIT licence (see LICENSE in this folder).
- Source: the official npm package `three@0.186.1`. These files are copied unchanged:
  - `three.module.js`  from `build/three.module.js`
  - `three.core.js`    from `build/three.core.js`   (three.module.js imports it, so the two must stay side by side)
  - `addons/loaders/HDRLoader.js`  from `examples/jsm/loaders/HDRLoader.js`  (loads the sky; it imports "three")
- The import map in index.html points "three" and "three/addons/" at this folder.
- To upgrade: take the same files from the new version, replace these, and test the game.
