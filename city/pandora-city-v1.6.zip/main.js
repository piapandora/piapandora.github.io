// main.js: the game's entry point. index.html only holds the page markup and loads this file.
// It wires the modules together (level, world, player, interface) and owns the game flow: score,
// win screen, restart, saving the map with M, and the animation loop. Everything else lives in
// the modules it imports, which all live in the modules/ folder.

import * as THREE from 'three';
import { PandoraController } from './modules/pandoraController.js';
import {
    GAME_VERSION, targetScore, collectiblesCount, posterRewardInterval, DEBUG_MODE_DONT_FORGET,
    PLAYER_HEIGHT, PLAYER_RADIUS, MAX_FEET_HEIGHT, PICKUP_DISTANCE, SPAWN, LEVEL_COLS, LEVEL_ROWS,
} from './modules/config.js';
import { playCollect, playGallery } from './modules/audio.js';
import {
    groundMaterials, upperMaterial, roofMaterial, landmarkMaterial, wallMaterial,
    fallbackMaterial, posterMatCache,
} from './modules/materials.js';
import { createHints } from './modules/hints.js';
import { pickLevel } from './modules/levelLoader.js';
import { gridToCSV, csvFileName } from './modules/levelFormat.js';
import { buildMap } from './modules/builder.js';
import { level } from './modules/levelState.js';
import { createCollectibles } from './modules/collectibles.js';
import { createGallery } from './modules/gallery.js';
import { worldBounds } from './modules/grid.js';
import { setupScene } from './modules/sceneSetup.js';
import * as ui from './modules/ui.js';

let score = 0;

ui.setTarget(targetScore);
ui.setVersion(`v${GAME_VERSION}`);
console.info(`[game] Pia Parkour v${GAME_VERSION}`);

let gameFinished = false;
let isContinued = false;
let winShown = false;
let winFallbackTimer = null;

const { scene, camera, renderer, sky } = setupScene();

const controls = new PandoraController(camera, renderer.domElement, {
    playerHeight: PLAYER_HEIGHT,
    playerRadius: PLAYER_RADIUS,
    spawn: SPAWN,
    maxHeight: MAX_FEET_HEIGHT,
    bounds: worldBounds(LEVEL_COLS, LEVEL_ROWS),
    colliders: () => level.obstacleColliders,
    keys: {
        forward:  ['KeyW', 'ArrowUp'],
        backward: ['KeyS', 'ArrowDown'],
        left:     ['KeyA', 'ArrowLeft'],
        right:    ['KeyD', 'ArrowRight'],
    },
    // runMode: 'toggle',   // uncomment for press-to-toggle running
});
ui.onInstructionsClick(() => {
    if (!ui.isWinScreenVisible()) controls.lock();
});

controls.addEventListener('lock', () => {
    ui.hideInstructions();
});

// The browser can refuse to lock the pointer, for example when "Play Again" is clicked right after Esc was
// pressed. Show the start screen again, so there is always something to click to try once more (that click
// is a fresh request). Without this the game would sit there with nothing on screen to click.
controls.addEventListener('lockerror', () => {
    ui.showInstructions();
});

function finishWin() {
    if (winShown) return;
    winShown = true;
    clearTimeout(winFallbackTimer);
    controls.velocity.set(0, 0, 0);
    controls.unlock();
    ui.showWinScreen();
}

controls.addEventListener('unlock', () => {
    controls.resetInput();
    if (gameFinished) {
        controls.velocity.set(0, 0, 0);
        if (!winShown) { finishWin(); return; }
    }
    if (score < targetScore && !ui.isWinScreenVisible()) {
        ui.showInstructions();
    } else if (gameFinished && isContinued) {
        ui.showWinScreen();
    }
});

const wireframeMat = new THREE.MeshBasicMaterial({ color: 0x00ffcc, wireframe: true });
let isWireframeActive = false;

// The map on screen, kept so that M can save it (declared here, before the level has finished
// loading, so an early keypress can never meet a variable that does not exist yet)
let currentMap = null;

// Press M to save the map you are playing as a CSV file (it goes to your Downloads folder).
// To play it again (edited or not), rename it to a free slot such as pandora-city-22.csv in the
// levels folder and open the game with ?22 on the end of the address.
function saveCurrentMap() {
    if (!currentMap) return;
    const fileName = csvFileName();
    ui.downloadTextFile(fileName, gridToCSV(currentMap.grid));
    ui.showMapSavedToast(fileName);
    console.info(`[levels] saved "${currentMap.name}" as ${fileName}`);
}

window.addEventListener('keydown', (e) => {
    if (e.code === 'KeyM' && !e.repeat && !e.ctrlKey && !e.metaKey && !e.altKey) saveCurrentMap();
    if (DEBUG_MODE_DONT_FORGET && e.code === 'KeyP') {
        isWireframeActive = !isWireframeActive;
        scene.overrideMaterial = isWireframeActive ? wireframeMat : null;
    }
});

// The pickup cubes and the gallery boxes. Both read the shared level state.
const collectibles = createCollectibles({ scene, level });
const gallery = createGallery({
    scene,
    level,
    getPlayerPosition: () => controls.object.position,
    getPosterImages: () => (typeof posterImages !== 'undefined' ? posterImages : []),
    cellHasCube: collectibles.cellHasCube,
});

// Which level to play: a NEW RANDOM CITY every time, unless the page address names a level.
// ?22 or ?level=22 plays levels/pandora-city-22.csv instead, and Play Again replays it.
// (A level that is missing or breaks a rule is reported in the console and a random city is played.)
const chosenLevel = await pickLevel(location.search);

// Start (or restart) the level: build it and fit the player's bounds to its size.
function loadLevel() {
    const grid = chosenLevel.makeGrid();
    currentMap = { name: chosenLevel.name, grid };
    buildMap(scene, grid);
    controls.bounds = worldBounds(level.cols, level.rows);
    console.info(`[levels] playing "${chosenLevel.name}" (${level.cols}x${level.rows})`);
}

loadLevel();
collectibles.spawn();

ui.onRestart(() => {
    score = 0;
    ui.setScore(score);
    gameFinished = false;
    isContinued = false;
    controls.inputLocked = false;
    winShown = false;
    clearTimeout(winFallbackTimer);
    ui.setScoreboardVisible(true);
    ui.hideWinScreen();
    sky.restart();                  // a new game: a new sky (or the pinned one again)

    collectibles.clear();

    const sharedMaterials = new Set([...groundMaterials, upperMaterial, roofMaterial, landmarkMaterial, wallMaterial, fallbackMaterial, ...posterMatCache.values()]);
    level.dynamicMeshes.forEach(mesh => {
        scene.remove(mesh);
        if (mesh.isInstancedMesh) mesh.dispose();
        if (mesh.geometry) mesh.geometry.dispose();
        const mats = Array.isArray(mesh.material) ? mesh.material : (mesh.material ? [mesh.material] : []);
        mats.forEach(m => {
            if (sharedMaterials.has(m)) return;
            if (m.isMeshBasicMaterial && m.map) m.map.dispose();
            m.dispose();
        });
    });
    level.dynamicMeshes.length = 0;

    loadLevel();
    collectibles.spawn();
    controls.teleportToSpawn();
    controls.lock();
});

ui.onContinue(() => {
    isContinued = true;
    controls.inputLocked = false;
    controls.velocity.set(0, 0, 0);
    controls.resetInput();
    ui.setScoreboardVisible(false);
    ui.hideWinScreen();
    controls.lock();
});

// ==========================================
// LAST-PICKUP HINTS
// ==========================================

const hints = createHints({
    scene,
    getCollectibles: () => collectibles.items,
    onAnnounce: ui.showHintToast,
});

let prevTime = performance.now();
function animate() {
    requestAnimationFrame(animate);
    const time = performance.now();
    const delta = Math.min((time - prevTime) / 1000, 0.05);

    hints.update(delta, gameFinished);

    collectibles.update(delta);

    if (controls.isLocked === true) {
        controls.update(delta);

        if (gameFinished && !winShown &&
            Math.hypot(controls.velocity.x, controls.velocity.z) < 0.05 && controls.isGrounded) {
            finishWin();
        }

        collectibles.items.forEach((cube) => {
            if (cube.visible) {
                if (controls.object.position.distanceTo(cube.position) < PICKUP_DISTANCE) {
                    score++;
                    ui.setScore(score);
                    playCollect();

                    if (score % posterRewardInterval === 0 && score < targetScore && gallery.spawnBox()) {
                        playGallery();
                        ui.showPosterToast();
                        sky.next();                 // a new sky for the new gallery
                    }

                    if (score <= targetScore - collectiblesCount) {
                        collectibles.relocate(cube);
                    } else {
                        cube.visible = false;
                        scene.remove(cube);
                    }

                    if (score >= targetScore && !gameFinished) {
                        gameFinished = true;
                        controls.inputLocked = true;
                        controls.resetInput();
                        winFallbackTimer = setTimeout(finishWin, 4000);
                    }
                }
            }
        });
    }
    prevTime = time;
    renderer.render(scene, camera);
}
animate();

// The game is running: remove the "has not started yet" safety-net box from index.html
ui.hideBootMessage();
