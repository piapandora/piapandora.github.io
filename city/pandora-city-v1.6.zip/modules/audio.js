// Small round-robin audio pools so rapid pickups don't cut each other off
// Sounds are decoded once into AudioBuffers and each play() starts its own source, so rapid
// back-to-back dings can overlap and never depend on a shared <audio> element's state.
// If Web Audio or the fetch fails, it falls back to a (lazily created) pool of <audio> elements.
const audioState = { ctx: null, loaders: [] };
function initAudio() {
	if (audioState.ctx) return;
	const AC = window.AudioContext || window.webkitAudioContext;
	if (!AC) return;
	audioState.ctx = new AC();
	audioState.loaders.forEach(load => load());
}
['pointerdown', 'keydown', 'click'].forEach(ev => window.addEventListener(ev, () => {
	initAudio();
	if (audioState.ctx && audioState.ctx.state === 'suspended') audioState.ctx.resume();
}, true));

function makeSoundPool(src, volume, size) {
	let pool = null, n = 0, buffer = null;
	const playFallback = () => {
		if (!pool) pool = Array.from({ length: size }, () => { const a = new Audio(src); a.volume = volume; return a; });
		const s = pool[n++ % size];
		try { s.currentTime = 0; } catch (e) {}
		s.play().catch(() => {});
	};
	const load = () => {
		fetch(src)
			.then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.arrayBuffer(); })
			.then(data => audioState.ctx.decodeAudioData(data))
			.then(buf => { buffer = buf; })
			.catch(err => console.warn('[audio] Web Audio load failed for ' + src + ', using <audio> fallback', err));
	};
	audioState.loaders.push(load);
	if (audioState.ctx) load();
	return () => {
		const ctx = audioState.ctx;
		if (!buffer || !ctx) { playFallback(); return; }
		if (ctx.state === 'suspended') ctx.resume();
		const source = ctx.createBufferSource();
		source.buffer = buffer;
		const gain = ctx.createGain();
		gain.gain.value = volume;
		source.connect(gain).connect(ctx.destination);
		source.start();
	};
}
export const playCollect = makeSoundPool('audio/ding.wav', 0.75, 6);
export const playGallery = makeSoundPool('audio/giggle.wav', 0.25, 2);