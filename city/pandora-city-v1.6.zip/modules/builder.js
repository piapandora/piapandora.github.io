// builder.js: turns a level grid (see levelFormat.js) into the 3D world.
// It decides how things LOOK and what is SOLID, never what goes WHERE: the grid comes from the
// generator or from a CSV file.
import * as THREE from 'three';
import { SPAWN } from './config.js';
import { groundMaterialFor, upperMaterial, roofMaterial, wallMaterial, landmarkMaterial } from './materials.js';
import { CELL_SIZE, STOREY_HEIGHT, gridToWorld, spawnZoneCells } from './grid.js';
import { level } from './levelState.js';
import { cellInfo, reachableCells } from './levelFormat.js';
import { shuffleInPlace } from './shuffleBag.js';

function validateGrid(grid) {
    if (!Array.isArray(grid) || grid.length === 0 || !Array.isArray(grid[0]) || grid[0].length === 0) {
        throw new Error('buildMap: the level grid is empty.');
    }
    const cols = grid[0].length;
    grid.forEach((row, z) => {
        if (row.length !== cols) throw new Error(`buildMap: row ${z + 1} has ${row.length} columns, expected ${cols}.`);
        row.forEach((code, x) => {
            if (cellInfo(code) === null) throw new Error(`buildMap: row ${z + 1}, column ${x + 1}: "${code}" is not a valid cell code.`);
        });
    });
}

/**
 * Build the level into `scene` and fill the shared `level` state.
 * The caller disposes the previous level's meshes (level.dynamicMeshes) first.
 * @param {THREE.Scene} scene
 * @param {string[][]} grid  grid[row][col] of cell codes
 */
export function buildMap(scene, grid) {
    validateGrid(grid);
    level.reset();
    const rows = grid.length, cols = grid[0].length;
    level.cols = cols;
    level.rows = rows;
    const worldX = x => gridToWorld(x, cols), worldZ = z => gridToWorld(z, rows);

    // Cubes are batched into InstancedMeshes, one per unique (side, top, underside) material set.
    // A box's faces are, in three.js order: right, left, top, underside, front, back.
    const cubeGeo = new THREE.BoxGeometry(CELL_SIZE, STOREY_HEIGHT, CELL_SIZE);
    const batches = new Map();
    const addInstance = (sideMat, topMat, x, y, z, bottomMat = sideMat) => {
        const key = sideMat.uuid + '|' + topMat.uuid + '|' + bottomMat.uuid;
        if (!batches.has(key)) batches.set(key, { mats: [sideMat, sideMat, topMat, bottomMat, sideMat, sideMat], matrices: [] });
        batches.get(key).matrices.push(new THREE.Matrix4().makeTranslation(x, y, z));
    };
    // One solid box per run of storeys, from the bottom of storey `from` to the top of storey `to`
    // (a building is one run from the ground; a bridge is one run in the air; a window wall is two runs)
    const addCollider = (x, z, to, from = 1) => {
        const bottom = (from - 1) * STOREY_HEIGHT, height = (to - from + 1) * STOREY_HEIGHT;
        level.obstacleColliders.push(new THREE.Box3().setFromCenterAndSize(
            new THREE.Vector3(worldX(x), bottom + height / 2, worldZ(z)), new THREE.Vector3(CELL_SIZE, height, CELL_SIZE)));
    };

    // Walls, buildings, taken cells and plaza centres, in one pass over the grid
    const plazas = [];
    for (let z = 0; z < rows; z++) {
        for (let x = 0; x < cols; x++) {
            const info = cellInfo(grid[z][x]);
            if (info.wall) {
                addInstance(wallMaterial, roofMaterial, worldX(x), STOREY_HEIGHT / 2, worldZ(z));
                addCollider(x, z, 1);
            } else if (info.shape) {   // before "storeys > 0": the window wall "p" also has a 1-storey sill
                // A special shape (shapes.js): a cube for every solid storey. A storey with open air below
                // shows the landmark (floor tile) texture underneath (no windows facing down); a storey with open air
                // above gets a roof. The ground storey of a shape (the sill of "p") looks like a 1-storey building.
                const solid = info.solid;
                for (const s of solid) {
                    const sideMat = (s === 1) ? groundMaterialFor(info.storeys) : upperMaterial;
                    const topMat = solid.includes(s + 1) ? sideMat : roofMaterial;
                    const bottomMat = (s === 1 || solid.includes(s - 1)) ? sideMat : landmarkMaterial;
                    addInstance(sideMat, topMat, worldX(x), (s - 0.5) * STOREY_HEIGHT, worldZ(z), bottomMat);
                }
                for (let i = 0; i < solid.length; i++) {
                    let j = i;
                    while (j + 1 < solid.length && solid[j + 1] === solid[j] + 1) j++;
                    addCollider(x, z, solid[j], solid[i]);
                    i = j;
                }
            } else if (info.storeys > 0) {
                // The ground floor's look depends on the building's height (ground-floor-1.png for 1 storey, -2 for 2, ... -6 for 6 and above)
                const groundLook = groundMaterialFor(info.storeys);
                for (let h = 0; h < info.storeys; h++) {
                    const sideMat = (h === 0) ? groundLook : upperMaterial;
                    const topMat = (h === info.storeys - 1) ? roofMaterial : sideMat;
                    addInstance(sideMat, topMat, worldX(x), (h + 0.5) * STOREY_HEIGHT, worldZ(z));
                }
                addCollider(x, z, info.storeys);
            }
            // Taken cells: no gallery goes here. Under a shape is taken too: a gallery box (6.67 m) is
            // taller than the 5 m under a gate, and a box half inside a bridge would look broken.
            if (info.wall || info.storeys > 0 || info.plaza || info.shape) level.occupiedGridRegistry.add(`${x},${z}`);
            if (info.plazaCentre) plazas.push({ ix: x, iz: z });
        }
    }
    const spawnCells = spawnZoneCells(cols, rows, SPAWN);
    spawnCells.forEach(c => level.occupiedGridRegistry.add(`${c.x},${c.z}`));

    // Floor: one instanced plane per cell (1 draw call)
    const floorGeo = new THREE.PlaneGeometry(CELL_SIZE, CELL_SIZE);
    floorGeo.rotateX(-Math.PI / 2);
    const floor = new THREE.InstancedMesh(floorGeo, landmarkMaterial, cols * rows);
    const floorMatrix = new THREE.Matrix4();
    for (let z = 0; z < rows; z++) {
        for (let x = 0; x < cols; x++) {
            floorMatrix.makeTranslation(worldX(x), 0, worldZ(z));
            floor.setMatrixAt(z * cols + x, floorMatrix);
        }
    }
    floor.instanceMatrix.needsUpdate = true;
    scene.add(floor);
    level.dynamicMeshes.push(floor);

    batches.forEach(({ mats, matrices }) => {
        const mesh = new THREE.InstancedMesh(cubeGeo, mats, matrices.length);
        matrices.forEach((m, i) => mesh.setMatrixAt(i, m));
        mesh.instanceMatrix.needsUpdate = true;
        scene.add(mesh);
        level.dynamicMeshes.push(mesh);
    });

    // Where the player can walk, and which plazas are usable. Plazas are shuffled because the
    // gallery takes them from the end of the list, and a grid scan would always favour one corner.
    const reach = reachableCells(grid, spawnCells);
    level.reachableCells = reach;
    level.landmarkPlazaCenters = shuffleInPlace(
        plazas.filter(p => reach.has(`${p.ix},${p.iz}`)).map(p => ({ x: worldX(p.ix), z: worldZ(p.iz) })));
}
