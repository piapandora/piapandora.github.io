// collectibles.js: the orange pickup cubes: spawning, random placement, spin, and "is a cube here?"
// Score and win rules stay in main.js; this module only knows about the cubes themselves.
import * as THREE from 'three';
import { collectiblesCount, SPAWN } from './config.js';
import { CELL_SIZE, gridToWorld } from './grid.js';

const CUBE_SIZE = 0.9;
const CUBE_Y = 1;          // height of a cube's centre above the ground
const SPIN_SPEED = 1.5;    // radians per second

// scene:  where cubes get added/removed
// level:  the shared level state (levelState.js). Read through it on every call, never copied,
//         because the builder replaces some of its fields on each rebuild.
export function createCollectibles({ scene, level }) {
    const geometry = new THREE.BoxGeometry(CUBE_SIZE, CUBE_SIZE, CUBE_SIZE);
	const material = new THREE.MeshLambertMaterial({ color: 0xff9024, emissive: 0xff3300, emissiveIntensity: 0.25 });

    // Mutated in place (never reassigned) so anyone holding a reference, like hints.js, stays valid.
    const items = [];

    function cellHasCube(ix, iz) {
        const wx = gridToWorld(ix, level.cols), wz = gridToWorld(iz, level.rows);
        return items.some(c => c.visible && Math.abs(c.position.x - wx) < CELL_SIZE / 2 && Math.abs(c.position.z - wz) < CELL_SIZE / 2);
    }

    // Every walkable cell a cube could go in. Walks the reachable set itself, so it needs no
    // knowledge of the grid size.
    function getGroundCells(avoidCubes = true) {
        const colliders = level.obstacleColliders;
        const galleryCentres = level.landmarkPlazaCenters;
        const cells = [];
        for (const key of level.reachableCells) {
            const [ix, iz] = key.split(',').map(Number);
            const wx = gridToWorld(ix, level.cols), wz = gridToWorld(iz, level.rows);
            if (Math.abs(wx - SPAWN.x) <= CELL_SIZE && Math.abs(wz - SPAWN.z) <= CELL_SIZE) continue;
            // only boxes down at cube height count: a bridge high overhead leaves the street below free
            const solid = colliders.some(b => wx > b.min.x && wx < b.max.x && wz > b.min.z && wz < b.max.z && b.min.y < CUBE_Y + CUBE_SIZE / 2);
            if (solid) continue;
            const isGalleryCentre = galleryCentres.some(c => Math.abs(c.x - wx) < 0.1 && Math.abs(c.z - wz) < 0.1);
            if (isGalleryCentre) continue;
            if (avoidCubes && cellHasCube(ix, iz)) continue;
            cells.push({ x: wx, z: wz });
        }
        return cells;
    }

    function getRandomGridPosition() {
        let cells = getGroundCells(true);
        if (cells.length === 0) cells = getGroundCells(false);
        if (cells.length === 0) return { x: SPAWN.x + CELL_SIZE, z: SPAWN.z };
        return cells[Math.floor(Math.random() * cells.length)];
    }

    /** Move a cube to a random free cell (prefers cells with no other cube). */
    function relocate(cube) {
        const pos = getRandomGridPosition();
        cube.position.set(pos.x, CUBE_Y, pos.z);
    }

    /** Create the starting set of cubes. */
    function spawn() {
        for (let i = 0; i < collectiblesCount; i++) {
            const cube = new THREE.Mesh(geometry, material);
            relocate(cube);
            scene.add(cube);
            items.push(cube);
        }
    }

    /** Remove every cube from the scene (geometry and material are shared, so they stay). */
    function clear() {
        items.forEach(cube => scene.remove(cube));
        items.length = 0;
    }

    /** Spin the visible cubes. Call once per frame. */
    function update(delta) {
        items.forEach(cube => { if (cube.visible) cube.rotation.y += SPIN_SPEED * delta; });
    }

    return { items, cellHasCube, relocate, spawn, clear, update };
}
