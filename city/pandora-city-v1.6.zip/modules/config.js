// config.js: tuning values and fixed settings

// The version, shown on the start screen and in the console so you can always tell which build is running
export const GAME_VERSION = '1.6';

// Gameplay
export const targetScore = 110;
export const collectiblesCount = 10;
export const posterRewardInterval = 10;

// How many galleries a full game unlocks: one per reward, never at the winning score itself
// (110 points with a reward every 10 gives 10). The level generator makes this many plazas, and a
// level needs at least this many reachable plazas to be playable.
export const galleriesNeeded = Math.floor((targetScore - 1) / posterRewardInterval);

// Debug
export const DEBUG_MODE_DONT_FORGET = false;

// Player / world
export const PLAYER_HEIGHT = 1.6;
// How close the player can get to a wall, in metres (the player is a 0.45 m radius cylinder).
export const PLAYER_RADIUS = 0.45;
// The highest the player's FEET may go, in metres. The tallest roof is 9 storeys (45 m) and a double jump adds
// about 6 m, so 60 leaves room to spare: you never hit an invisible ceiling.
export const MAX_FEET_HEIGHT = 60;
// How close you must get to an orange cube to pick it up, in metres (from the player's position to the cube's centre).
export const PICKUP_DISTANCE = 2.5;
export const FLOOR_Y = PLAYER_HEIGHT;
export const SPAWN = { x: 0, z: 0 };

// Generated levels: size in cells INCLUDING the border walls, and how many cells thick the border is.
// 24 with a 2-cell border leaves a 20 x 20 playable area.
export const LEVEL_COLS = 24;
export const LEVEL_ROWS = 24;
export const BORDER_RINGS = 2;

// Gallery boxes are 5 wide (+/-2.5) and the player radius (PLAYER_RADIUS) is 0.45, so 3.5 keeps a margin.
export const GALLERY_PLAYER_CLEARANCE = 3.5;

// Last-pickup hints
export const HINT_THRESHOLD = 5;
export const HINT_HEIGHT = 140;
export const HINT_COLOR = [1.0, 0.90, 0.60];
export const SPOT_RADIUS = 3.5;