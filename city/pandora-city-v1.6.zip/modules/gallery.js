// gallery.js: the poster gallery boxes that appear every few pickups
// Deciding WHEN a gallery appears (score rules) stays in main.js; this module decides WHERE
// and builds the box.
import * as THREE from 'three';
import { GALLERY_PLAYER_CLEARANCE } from './config.js';
import { CELL_SIZE, gridToWorld } from './grid.js';
import { roofMaterial, loadPosterMaterial } from './materials.js';
import { createShuffleBag } from './shuffleBag.js';

const GALLERY_HEIGHT = 20 / 3;

// scene:              where gallery boxes get added
// level:              the shared level state (levelState.js). Read through it on every call, never
//                     copied, because the builder replaces some of its fields on each rebuild.
//                     A gallery uses up a plaza centre (removed in place), marks its cell occupied
//                     when it falls back to a free cell, and registers its mesh and collider.
// getPlayerPosition:  function returning the player's position (anything with x and z)
// getPosterImages:    function returning the array of poster image urls (may be empty)
// cellHasCube:        function (ix, iz) -> true if a visible collectible sits in that cell
export function createGallery({ scene, level, getPlayerPosition, getPosterImages, cellHasCube }) {
    // Poster order: every poster is shown once before any repeats, and a new round never starts with
    // the poster the last round ended on. The bag is made the first time posters are needed and kept
    // across restarts.
    let posterBag = null;
    function getRandomPosters(count = 4) {
        const images = getPosterImages();
        if (!images || images.length === 0) return [];     // no posters yet: the box shows the fallback poster
        if (!posterBag) posterBag = createShuffleBag(images);
        return Array.from({ length: count }, () => posterBag.next());
    }

    // Choose a world position for the next gallery, or null if the map has no free cell at all.
    function pickSpot() {
        const ppos = getPlayerPosition();
        const nearPlayer = (cx, cz) =>
            Math.abs(ppos.x - cx) < GALLERY_PLAYER_CLEARANCE && Math.abs(ppos.z - cz) < GALLERY_PLAYER_CLEARANCE;

        // A plaza is open ground on every side, so if the box appears on top of the player, the controller
        // simply pushes him out through the nearest face. A street cell is not safe like that: next to a wall
        // the push can shove the player into the wall, and a poster face can end up hidden against it. So a
        // gallery always goes on a plaza while one is left, even a plaza right next to the player, and a street
        // cell is only a last resort. A spot away from the player is just a preference, and a gallery is never
        // skipped (the 100-point gallery must always appear).
        const takePlaza = (allowNear) => {
            const lm = level.landmarkPlazaCenters || [];
            for (let i = lm.length - 1; i >= 0; i--) { // the end of the list first
                if (allowNear || !nearPlayer(lm[i].x, lm[i].z)) {
                    const c = lm.splice(i, 1)[0];
                    return { wx: c.x, wz: c.z };
                }
            }
            return null;
        };

        // No plaza left: any free walkable cell. Walks the reachable set itself, so it needs
        // no knowledge of the grid size.
        const takeStreetCell = (allowNear) => {
            const occupied = level.occupiedGridRegistry;
            const free = [];
            for (const key of level.reachableCells) {
                if (occupied.has(key)) continue;
                const [ix, iz] = key.split(',').map(Number);
                if (cellHasCube(ix, iz)) continue;
                if (!allowNear && nearPlayer(gridToWorld(ix, level.cols), gridToWorld(iz, level.rows))) continue;
                free.push({ ix, iz });
            }
            if (free.length === 0) return null;
            const pick = free[Math.floor(Math.random() * free.length)];
            occupied.add(`${pick.ix},${pick.iz}`);
            return { wx: gridToWorld(pick.ix, level.cols), wz: gridToWorld(pick.iz, level.rows) };
        };

        const plaza = takePlaza(false) || takePlaza(true);
        if (plaza) return plaza;
        console.warn('[gallery] no plaza is left, so this gallery was put on a street cell instead');
        return takeStreetCell(false) || takeStreetCell(true);
    }

    /** Place one gallery box. Returns false only if the map has no free cell at all. */
    function spawnBox() {
        const spot = pickSpot();
        if (!spot) return false;

        const boxPosters = getRandomPosters(4);
        const matList = [
            loadPosterMaterial(boxPosters[0]),
            loadPosterMaterial(boxPosters[1]),
            roofMaterial,
            roofMaterial,
            loadPosterMaterial(boxPosters[2]),
            loadPosterMaterial(boxPosters[3])
        ];
        const galleryGeo = new THREE.BoxGeometry(CELL_SIZE, GALLERY_HEIGHT, CELL_SIZE);
        const galleryMesh = new THREE.Mesh(galleryGeo, matList);
        galleryMesh.position.set(spot.wx, GALLERY_HEIGHT / 2, spot.wz);
        scene.add(galleryMesh);
        level.dynamicMeshes.push(galleryMesh);

        galleryMesh.geometry.computeBoundingBox();
        level.obstacleColliders.push(new THREE.Box3().setFromObject(galleryMesh));
        return true;
    }

    return { spawnBox };
}
