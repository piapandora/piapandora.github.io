// generator.js: builds a random level as a grid of cell codes (see levelFormat.js).
// It decides WHAT goes WHERE and nothing else: no meshes, no colliders, no materials. The builder
// turns any grid, generated or loaded from CSV, into the 3D level.
import { SPAWN, galleriesNeeded } from './config.js';
import { spawnZoneCells } from './grid.js';
import { EMPTY, FLOOR, WALL, NOVA, PODIUM, START, reachableCells } from './levelFormat.js';

// Building shapes: footprint (w x d), storey range, and how many are attempted.
// The 0-storey 3x3 entry is the gallery plaza. Its weight is galleriesNeeded (config.js): one plaza
// per gallery, so changing the score settings changes it automatically.
//
// DENSITY: this list is sized for a 20 x 20 playable area (a 24 x 24 map with a 2-cell border).
// The 93 buildings add up to 224 cells, which is 56.0% of the 400 playable cells. Until v1.4 it was
// 85 buildings and 198 cells (49.5%, the share of the original 18 x 18 map); playtests asked for more
// buildings, so v1.5 added one 1x1 (3-4 storeys), one 2x2 and one 2x4 (52.8%), and then three low 1x1s
// (1-2 storeys), two 1x2s and two 1x3s (56.0%): mostly low stepping stones. To make the city denser or
// sparser, raise or lower the counts together, and keep the 5-6 storey towers at about 7% of the
// building cells (15 of 224 now).
// A different map size needs a different list: this one works from 23 x 23 up (tight at 23, comfortable
// at 24) and leaves too little street on anything smaller, while on bigger maps it simply gets sparser.
// The same goes for more galleries: every plaza takes 9 cells, so a bigger galleriesNeeded leaves the
// buildings less room.
//
// PLAZAS: at most MAX_PLAZAS_TOUCHING plazas may form one joined group (sharing an edge; touching only
// at a corner does not count). Big joined groups made one huge open square with long sight lines,
// which playtests disliked. Separate pairs are fine. Plazas are placed first, on an empty map, so
// there is always room: 10,000 test cities all got their 10 plazas.
const BLUEPRINTS = [
    // 0-storey plazas
    { w: 3, d: 3, minS: 0, maxS: 0, weight: galleriesNeeded },

    // Standard 1x1 pillars and towers
    { w: 1, d: 1, minS: 1, maxS: 2, weight: 25 },
    { w: 1, d: 1, minS: 3, maxS: 4, weight: 20 },
    { w: 1, d: 1, minS: 5, maxS: 6, weight: 15 },

    // Narrow and slender
    { w: 1, d: 2, minS: 1, maxS: 3, weight: 10 },
    { w: 1, d: 3, minS: 1, maxS: 3, weight: 10 },

    // Medium blocks
    { w: 2, d: 2, minS: 1, maxS: 4, weight: 5 },

    // Rectangles
    { w: 2, d: 3, minS: 1, maxS: 3, weight: 3 },
    { w: 2, d: 4, minS: 1, maxS: 3, weight: 3 },
    { w: 3, d: 4, minS: 2, maxS: 4, weight: 3 },

    // Large monument blocks
    { w: 4, d: 4, minS: 2, maxS: 4, weight: 1 },
];

const PLACEMENT_ATTEMPTS = 80;
const MAX_PLAZAS_TOUCHING = 2;   // the biggest joined group of plazas allowed (see PLAZAS above)

/**
 * @param {Object} options
 * @param {number} options.cols        grid width in cells (including the border)
 * @param {number} options.rows        grid depth in cells (including the border)
 * @param {number} [options.borderRings=2]  thickness of the outer wall, in cells
 * @param {{x:number,z:number}} [options.spawn]  where the player starts (world coordinates)
 * @param {() => number} [options.rng=Math.random]  random source; pass a seeded one for repeatable levels
 * @returns {{ grid: string[][] }}
 */
export function generateLevel({ cols, rows, borderRings = 2, spawn = SPAWN, rng = Math.random }) {
    const grid = Array.from({ length: rows }, () => Array(cols).fill(EMPTY));

    // Outer wall
    let solidCount = 0;
    for (let z = 0; z < rows; z++) {
        for (let x = 0; x < cols; x++) {
            if (Math.min(x, z, cols - 1 - x, rows - 1 - z) < borderRings) { grid[z][x] = WALL; solidCount++; }
        }
    }
    const x0 = borderRings, z0 = borderRings;
    const innerW = cols - 2 * borderRings, innerD = rows - 2 * borderRings;

    // The cells around the spawn point stay open: nothing may be built on them (they become "S" at the end)
    const spawnCells = spawnZoneCells(cols, rows, spawn);
    if (spawnCells.length === 0 || spawnCells.some(c => c.x < x0 || c.x >= x0 + innerW || c.z < z0 || c.z >= z0 + innerD)) {
        throw new Error('generateLevel: the spawn zone must lie inside the playable area (grid too small for this border?).');
    }
    const reserved = new Set(spawnCells.map(c => `${c.x},${c.z}`));

    const footprintFree = (sx, sz, w, d) => {
        for (let z = sz; z < sz + d; z++) {
            for (let x = sx; x < sx + w; x++) {
                if (x < x0 || x >= x0 + innerW || z < z0 || z >= z0 + innerD) return false;
                if (grid[z][x] !== EMPTY || reserved.has(`${x},${z}`)) return false;
            }
        }
        return true;
    };

    // How many plazas one joined group would hold if a new 3x3 plaza went at (sx, sz): the new one
    // plus every plaza already touching it along an edge (directly, or through another plaza).
    const plazaGroupSize = (sx, sz) => {
        const isPlaza = (x, z) => grid[z][x] === NOVA || grid[z][x] === PODIUM;
        const seen = new Set(), stack = [];
        const visit = (x, z) => {
            if (x < 0 || z < 0 || x >= cols || z >= rows || seen.has(z * cols + x) || !isPlaza(x, z)) return;
            seen.add(z * cols + x); stack.push([x, z]);
        };
        for (let i = 0; i < 3; i++) { visit(sx + i, sz - 1); visit(sx + i, sz + 3); visit(sx - 1, sz + i); visit(sx + 3, sz + i); }
        let plazas = 1;
        while (stack.length) {
            const [x, z] = stack.pop();
            if (grid[z][x] === PODIUM) plazas++;
            visit(x + 1, z); visit(x - 1, z); visit(x, z + 1); visit(x, z - 1);
        }
        return plazas;
    };

    // Plazas first, then the biggest footprints, with 1x1 fillers last, so the big pieces still find room
    const queue = [];
    BLUEPRINTS.forEach(bp => { for (let i = 0; i < bp.weight; i++) queue.push({ ...bp }); });
    queue.sort((a, b) => {
        const aPlaza = a.minS === 0 && a.maxS === 0 ? 1 : 0;
        const bPlaza = b.minS === 0 && b.maxS === 0 ? 1 : 0;
        if (aPlaza !== bPlaza) return bPlaza - aPlaza;
        return b.w * b.d - a.w * a.d;
    });

    const seed = spawnCells[0];

    queue.forEach(bp => {
        let w = bp.w, d = bp.d;
        if (w !== d && rng() < 0.5) { const t = w; w = d; d = t; }
        const storeys = Math.floor(rng() * (bp.maxS - bp.minS + 1)) + bp.minS;
        if (w > innerW || d > innerD) return;   // doesn't fit in this grid at all

        for (let attempt = 0; attempt < PLACEMENT_ATTEMPTS; attempt++) {
            const sx = Math.floor(rng() * (innerW - w + 1)) + x0;
            const sz = Math.floor(rng() * (innerD - d + 1)) + z0;
            if (!footprintFree(sx, sz, w, d)) continue;

            if (storeys === 0) {
                if (plazaGroupSize(sx, sz) > MAX_PLAZAS_TOUCHING) continue;   // would make too big an open area
                // A plaza: 3x3 of N with a P in the middle (the gallery spot)
                for (let z = sz; z < sz + d; z++) for (let x = sx; x < sx + w; x++) grid[z][x] = NOVA;
                grid[sz + 1][sx + 1] = PODIUM;
                return;
            }

            const code = String(storeys);
            for (let z = sz; z < sz + d; z++) for (let x = sx; x < sx + w; x++) grid[z][x] = code;

            // A tall building (2+ storeys) blocks the street. Keep it only if every street cell
            // is still reachable from the spawn; otherwise undo it and try another spot.
            const blocks = storeys >= 2;
            if (!blocks) return;
            const open = cols * rows - (solidCount + w * d);
            if (reachableCells(grid, [seed]).size === open) { solidCount += w * d; return; }
            for (let z = sz; z < sz + d; z++) for (let x = sx; x < sx + w; x++) grid[z][x] = EMPTY;
        }
    });

    // Everything never touched is paved street
    for (let z = 0; z < rows; z++) for (let x = 0; x < cols; x++) if (grid[z][x] === EMPTY) grid[z][x] = FLOOR;

    // The cells at the centre of the map, where the player starts, are marked "S"
    spawnCells.forEach(c => { grid[c.z][c.x] = START; });

    return { grid };
}
