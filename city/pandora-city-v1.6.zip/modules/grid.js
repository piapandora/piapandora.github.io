// grid.js: cell and storey sizes, plus grid <-> world coordinate conversion
//
// The world is centred on the origin. With `count` cells along an axis, cell index 0 starts at
// -(count / 2) * CELL_SIZE, so cell i has its centre at (i - count / 2) * CELL_SIZE + CELL_SIZE / 2.
// For a 20-cell axis that is (i - 10) * 5 + 2.5.

export const CELL_SIZE = 5.0;      // width and depth of one grid cell (metres)
export const STOREY_HEIGHT = 5.0;  // height of one building storey (metres)

// Levels have different sizes, so callers must say how many cells the axis has (level.cols for x,
// level.rows for z). Forgetting throws straight away instead of quietly producing NaN.
function requireCount(count) {
    if (!Number.isFinite(count)) throw new Error('grid.js: pass the number of cells along that axis (level.cols or level.rows)');
}

/** World coordinate of the centre of cell `index` on an axis that is `count` cells long. */
export function gridToWorld(index, count) {
    requireCount(count);
    return (index - count / 2) * CELL_SIZE + CELL_SIZE / 2;
}

/**
 * Inverse of gridToWorld: the cell index containing world coordinate `w`.
 * The game itself does not need this; it is kept because it is the exact inverse of gridToWorld,
 * and the tests use it.
 */
export function worldToGrid(w, count) {
    requireCount(count);
    return Math.round((w - CELL_SIZE / 2) / CELL_SIZE + count / 2);
}

/** The edges of a cols x rows level in world coordinates, in the shape the controller's `bounds` wants. */
export function worldBounds(cols, rows) {
    const halfX = cols * CELL_SIZE / 2, halfZ = rows * CELL_SIZE / 2;
    return { minX: -halfX, maxX: halfX, minZ: -halfZ, maxZ: halfZ };
}

/**
 * The cells reserved around the player's spawn point: every cell whose centre is closer than one
 * cell size to `spawn` on both axes. For an even-sized grid with spawn at the origin that is the
 * 2x2 block around the centre (cells 9-10 on a 20-wide grid).
 * Returns [{x, z}] cell indices, scanned row by row.
 */
export function spawnZoneCells(cols, rows, spawn) {
    const cells = [];
    for (let z = 0; z < rows; z++) {
        for (let x = 0; x < cols; x++) {
            if (Math.abs(gridToWorld(x, cols) - spawn.x) < CELL_SIZE && Math.abs(gridToWorld(z, rows) - spawn.z) < CELL_SIZE) {
                cells.push({ x, z });
            }
        }
    }
    return cells;
}
