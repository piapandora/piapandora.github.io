// hints.js: light beams and pulsing on the last few collectibles
import * as THREE from 'three';
import { HINT_THRESHOLD, HINT_HEIGHT, HINT_COLOR, SPOT_RADIUS } from './config.js';

// scene:           where beams get added/removed
// getCollectibles: function returning the current array of collectible meshes
// onAnnounce:      called once each time the hints switch on (main.js shows the toast)
export function createHints({ scene, getCollectibles, onAnnounce }) {
    const hintUniforms = {
        uTime: { value: 0 },
        uColor: { value: new THREE.Vector3(...HINT_COLOR) },
        uHeight: { value: HINT_HEIGHT }
    };

    const beamMaterial = new THREE.ShaderMaterial({
        uniforms: hintUniforms,
        transparent: true, depthWrite: false, side: THREE.DoubleSide, fog: false,
        vertexShader: `
            uniform float uHeight;
            varying float vH;
            varying vec3 vN;
            varying vec3 vV;
            void main() {
                vH = position.y / uHeight;
                vec4 mv = modelViewMatrix * vec4(position, 1.0);
                vN = normalize(normalMatrix * normal);
                vV = normalize(-mv.xyz);
                gl_Position = projectionMatrix * mv;
            }`,
        fragmentShader: `
            uniform vec3 uColor;
            uniform float uTime;
            varying float vH;
            varying vec3 vN;
            varying vec3 vV;
            void main() {
                float edge = abs(dot(normalize(vN), normalize(vV)));
                float soft = pow(edge, 1.4);
                float fade = pow(1.0 - clamp(vH, 0.0, 1.0), 1.6);
                float ripple = 0.88 + 0.12 * sin(uTime * 2.2 - vH * 14.0);
                float a = soft * (0.08 + 0.45 * fade) * ripple;
                gl_FragColor = vec4(uColor, a);
            }`
    });

    const spotMaterial = new THREE.ShaderMaterial({
        uniforms: hintUniforms,
        transparent: true, depthWrite: false, fog: false,
        vertexShader: `
            varying vec2 vP;
            void main() {
                vP = position.xz;
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }`,
        fragmentShader: `
            uniform vec3 uColor;
            uniform float uTime;
            varying vec2 vP;
            void main() {
                float r = clamp(length(vP) / ${SPOT_RADIUS.toFixed(1)}, 0.0, 1.0);
                float pulse = 0.85 + 0.15 * sin(uTime * 2.2);
                gl_FragColor = vec4(uColor, pow(1.0 - r, 1.8) * 0.5 * pulse);
            }`
    });

    const beamGeometry = new THREE.CylinderGeometry(1.7, 1.1, HINT_HEIGHT, 24, 1, true);
    beamGeometry.translate(0, HINT_HEIGHT / 2, 0);
    const spotGeometry = new THREE.CircleGeometry(SPOT_RADIUS, 32);
    spotGeometry.rotateX(-Math.PI / 2);

    const hintBeams = new Map();
    let hintAnnounced = false;

    function update(delta, gameFinished) {
        hintUniforms.uTime.value += delta;
        const collectibles = getCollectibles();
        const alive = collectibles.filter(c => c.visible);
        const active = !gameFinished && alive.length > 0 && alive.length <= HINT_THRESHOLD;

        for (const [cube, group] of hintBeams) {
            if (!active || !cube.visible || !collectibles.includes(cube)) {
                scene.remove(group);
                hintBeams.delete(cube);
            }
        }

        if (active) {
            alive.forEach(cube => {
                cube.scale.setScalar(1.25 + 0.12 * Math.sin(hintUniforms.uTime.value * 3.0));
                if (hintBeams.has(cube)) return;
                const group = new THREE.Group();
                const spot = new THREE.Mesh(spotGeometry, spotMaterial);
                spot.position.y = 0.05;
                group.add(new THREE.Mesh(beamGeometry, beamMaterial), spot);
                group.position.set(cube.position.x, 0, cube.position.z);
                scene.add(group);
                hintBeams.set(cube, group);
            });
            if (!hintAnnounced) {
                hintAnnounced = true;
                onAnnounce();
            }
        } else {
            hintAnnounced = false;
        }
    }

    return { update };
}