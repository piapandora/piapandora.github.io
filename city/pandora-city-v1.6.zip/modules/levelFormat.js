// levelFormat.js: the level notation (the cell codes used in level CSV files) and what each code means in Pia Parkour.
// Pure logic only (no THREE, no DOM), so the generator, the builder, the CSV loader and the
// validator can all share it.
//
// A level is a grid of one-character codes, grid[row][col]. Column = x, row = z.
//   0  open ground (paved)              E  open ground (leftover)
//   W  wall (one storey, solid)         1-9  a building of that many storeys
//   N  plaza cell                       P  plaza centre: where a gallery appears
//   S  the player's start: the cells at the centre of the map (plain open ground)
//   a-z  special shapes (bridges, gates, windows): see shapes.js. Only the ACTIVE letters are valid.
//   Q  L  reserved for the future; treated as plain open ground for now

import { shapeStoreys, ACTIVE_LETTERS } from './shapes.js';

export const FLOOR = '0', EMPTY = 'E', WALL = 'W', NOVA = 'N', QUAD = 'Q', LINK = 'L', PODIUM = 'P', START = 'S';

// A double jump (~6.25 high) clears a 1-storey building (5 high) but not a 2-storey one (10).
// So 2+ storeys block the street; 1 storey does not.
export const MIN_BLOCKING_STOREYS = 2;

export function isValidCode(v) {
    if (v === FLOOR || v === EMPTY || v === WALL || v === NOVA || v === QUAD || v === LINK || v === PODIUM || v === START) return true;
    if (/^[1-9]$/.test(v)) return true;   // building storeys 1-9
    if (shapeStoreys(v) !== null) return true;   // an active special shape (shapes.js)
    return false;
}

const NONE = Object.freeze([]);
const info = (storeys, extra = {}) => Object.freeze({
    storeys, solid: Object.freeze(Array.from({ length: storeys }, (_, i) => i + 1)),
    wall: false, plaza: false, plazaCentre: false, start: false, shape: false, ...extra });
const OPEN = info(0, { solid: NONE });
const PLAZA = info(0, { solid: NONE, plaza: true });
const PLAZA_CENTRE = info(0, { solid: NONE, plaza: true, plazaCentre: true });
const WALL_INFO = info(1, { wall: true });
const START_INFO = info(0, { solid: NONE, start: true });
const STOREY_INFO = [null, ...Array.from({ length: 9 }, (_, i) => info(i + 1))];
// A special shape: `solid` lists every solid storey; `storeys` counts only the ones standing on the ground
// (from storey 1 up without a gap), because that is the part you walk into. b (storey 3 alone) and
// i (storeys 2-3) have 0: open ground underneath. p (storeys 1 and 3) has 1: you hop onto its sill.
const SHAPE_INFO = Object.fromEntries(ACTIVE_LETTERS.map(letter => {
    const solid = shapeStoreys(letter);
    let ground = 0;
    while (solid.includes(ground + 1)) ground++;
    return [letter, info(ground, { solid, shape: true })];
}));

/**
 * What a cell code means in the game:
 *   storeys      how many 5 m storeys stand on the ground without a gap (0 = flat ground, or open below a shape)
 *   solid        every solid storey, lowest first: [1, 2, 3] for "3", [3] for the bridge "b", [] for open ground
 *   shape        a special shape (a lowercase letter, see shapes.js)
 *   wall         a wall cell (solid, one storey)
 *   plaza        part of a 3x3 plaza (flat ground that nothing else may be built on)
 *   plazaCentre  the middle of a plaza: where a gallery box appears
 *   start        part of the player's start area at the centre of the map (open ground)
 * Returns null for an invalid code.
 */
export function cellInfo(code) {
    if (code === WALL) return WALL_INFO;
    if (code === NOVA) return PLAZA;
    if (code === PODIUM) return PLAZA_CENTRE;
    if (code === START) return START_INFO;
    if (/^[1-9]$/.test(code)) return STOREY_INFO[Number(code)];
    if (Object.prototype.hasOwnProperty.call(SHAPE_INFO, code)) return SHAPE_INFO[code];
    return isValidCode(code) ? OPEN : null;   // 0, E, Q, L: open ground
}

/** True if a cell blocks walking along the street: a wall, or a building of 2+ storeys. */
export function isSolid(code) {
    const info = cellInfo(code);
    return info !== null && (info.wall || info.storeys >= MIN_BLOCKING_STOREYS);
}

/**
 * Flood-fill the cells a player can walk to. Starts from `seeds` ([{x, z}] cell indices), spreads
 * to the four neighbours, and never enters a solid cell or leaves the grid.
 * Returns a Set of "x,z" keys (the same key format the rest of the game uses).
 * Note that 1-storey buildings count as walkable, because a double jump clears them.
 */
export function reachableCells(grid, seeds) {
    const rows = grid.length, cols = rows ? grid[0].length : 0;
    const reach = new Set();
    const stack = seeds.map(s => `${s.x},${s.z}`);
    while (stack.length) {
        const key = stack.pop();
        if (reach.has(key)) continue;
        const [x, z] = key.split(',').map(Number);
        if (x < 0 || x >= cols || z < 0 || z >= rows || isSolid(grid[z][x])) continue;
        reach.add(key);
        stack.push(`${x + 1},${z}`, `${x - 1},${z}`, `${x},${z + 1}`, `${x},${z - 1}`);
    }
    return reach;
}

/** The grid as CSV text (one row per line). parseLevelCSV reads it back exactly. */
export function gridToCSV(grid) {
    return grid.map(row => row.join(',')).join('\r\n') + '\r\n';
}

// Level files are called pandora-city-<something>.csv. A saved map gets the time as its <something>;
// the game loads the ones whose <something> is a slot number (pandora-city-22.csv, see levelLoader.js).
export const LEVEL_FILE_PREFIX = 'pandora-city-';

/**
 * The file name used when a map is saved as CSV: the prefix and the time in milliseconds since
 * 1 January 1970, e.g. "pandora-city-1761577443000.csv". Every save gets a different name.
 */
export function csvFileName(timeMs = Date.now()) {
    return `${LEVEL_FILE_PREFIX}${timeMs}.csv`;
}

/**
 * Read level CSV text into a grid. Accepts what Excel, Google Sheets and text editors save:
 * an optional leading BOM, any line ending, comma / semicolon / tab separators, blank
 * lines, and stray spaces. Unlike a parser that stops at the first mistake, this reports EVERY
 * problem it finds, so a level can be fixed in one go. Rows and columns are counted from 1.
 * @returns {{ grid: string[][] | null, errors: string[] }}  grid is null when there are errors
 */
export function parseLevelCSV(text, { maxDimension = 60, maxErrors = 10 } = {}) {
    if (typeof text !== 'string') return { grid: null, errors: ['The level is not text.'] };
    const lines = text.replace(/^\uFEFF/, '').split(/\r\n|\n|\r/).map(l => l.trim()).filter(l => l.length > 0);
    if (lines.length === 0) return { grid: null, errors: ['The file is empty.'] };
    if (lines.length > maxDimension) return { grid: null, errors: [`The file has ${lines.length} rows; the maximum is ${maxDimension}.`] };

    const errors = [];
    let badCodes = 0;
    const grid = lines.map((line, r) => line.split(/[,;\t]/).map((cell, c) => {
        const v = cell.trim();
        if (v === '' || !isValidCode(v)) {
            badCodes++;
            if (badCodes <= maxErrors) errors.push(/^[a-z]$/.test(v)
                ? `Row ${r + 1}, column ${c + 1}: "${v}" is not a special shape the game can build yet (the shapes in use are ${ACTIVE_LETTERS.join(', ')}; see shapes.js).`
                : `Row ${r + 1}, column ${c + 1}: "${v}" is not a valid cell code (use 0, E, W, N, Q, L, P, S, 1-9 or a shape letter: ${ACTIVE_LETTERS.join(', ')}).`);
        }
        return v;
    }));
    if (badCodes > maxErrors) errors.push(`...and ${badCodes - maxErrors} more invalid cell codes.`);

    const width = grid[0].length;
    if (width > maxDimension) errors.push(`The file has ${width} columns; the maximum is ${maxDimension}.`);
    let ragged = 0;
    grid.forEach((row, r) => {
        if (row.length !== width) { ragged++; if (ragged <= maxErrors) errors.push(`Row ${r + 1} has ${row.length} columns, expected ${width}.`); }
    });
    if (ragged > maxErrors) errors.push(`...and ${ragged - maxErrors} more rows with the wrong number of columns.`);

    return { grid: errors.length ? null : grid, errors };
}
