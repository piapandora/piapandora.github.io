// levelLoader.js: chooses the level to play.
//
// With no level number in the page address, every game is a NEW RANDOM CITY.
// With a number, the game plays that level instead, and Play Again replays it:
//
//     yoursite/?22           plays levels/pandora-city-22.csv
//     yoursite/?level=22     the same
//     yoursite/?1  ?01       both play levels/pandora-city-01.csv
//
// Nothing is listed anywhere: a level is just a file called pandora-city-NN.csv in the levels folder.
// To make a saved map (pandora-city-<long number>.csv) part of the game, rename it to a free slot.
// A level that is missing or breaks a rule is skipped with a message in the browser console (F12)
// saying exactly which file and why, and a random city is played instead.
//
// Caching: level files are always fetched fresh. Every request adds a unique "?t=<time>" to the
// address, so no cache along the way (the browser, Cloudflare, or anything else in between) can
// hand back an old copy of a level that was edited, renamed or deleted. Level files are tiny, so
// skipping the caches costs nothing noticeable. (Why this matters: Cloudflare's CDN caches by file
// extension, and .csv is on its default list, with the query string as part of the cache key. So an
// old level file can stick, while a request with a different ?t= always gets the current one.)
//
// Missing files: some hosts (Cloudflare Pages without a 404.html, for example) answer a missing
// file with the site's home page and a normal "200 OK". That page is detected and treated as a
// missing file, so it can never be mistaken for a level.
import { generateLevel } from './generator.js';
import { LEVEL_FILE_PREFIX, parseLevelCSV } from './levelFormat.js';
import { validateLevel } from './levelValidator.js';
import { LEVEL_COLS, LEVEL_ROWS, BORDER_RINGS } from './config.js';

const LEVELS_FOLDER = 'levels';
const CACHE_BUST_PARAM = 't';        // the name used in "?t=<time>"; any name the server ignores works
const FETCH_TIMEOUT_MS = 6000;       // give up on a level file after 6 seconds and play a random city. Kept shorter than the
                                     // 10 seconds after which index.html shows its "has not started yet" box, so a stuck
                                     // level file falls back to a random city before that box would appear

/**
 * Read the level number from the page address (location.search), e.g. "?22" or "?level=22".
 * Leading zeros are fine ("?01" is level 1). Anything that is not a whole number from 1 to 9999
 * is not a level. `problem` is set only when a "level=" was given but cannot be used, so the
 * console can say so; unrelated parts of the address are ignored silently.
 * @returns {{ number: number | null, problem: string | null }}
 */
export function levelNumberFromQuery(search) {
    const params = new URLSearchParams(search);
    const asNumber = text => {
        const t = String(text).trim();
        return /^\d{1,4}$/.test(t) && Number(t) >= 1 ? Number(t) : null;
    };

    const levelKey = [...params.keys()].find(key => key.toLowerCase() === 'level');   // ?level=22, ?Level=22, ?LEVEL=22
    if (levelKey !== undefined) {
        const raw = params.get(levelKey);
        const number = asNumber(raw);
        return number !== null
            ? { number, problem: null }
            : { number: null, problem: `level=${raw} is not a level number (use a whole number from 1, like ?22 or ?level=22)` };
    }
    for (const [key, value] of params) {                 // the short form: ?22
        const number = value === '' ? asNumber(key) : null;
        if (number !== null) return { number, problem: null };
    }
    return { number: null, problem: null };
}

/** The file for a level number: 1 -> levels/pandora-city-01.csv, 22 -> levels/pandora-city-22.csv. */
export function levelFileName(number) {
    return `${LEVELS_FOLDER}/${LEVEL_FILE_PREFIX}${String(number).padStart(2, '0')}.csv`;
}

/** A level that makes a brand new random city every time it is asked for one. */
export function makeRandomCity() {
    return {
        name: 'Random city',
        makeGrid: () => generateLevel({ cols: LEVEL_COLS, rows: LEVEL_ROWS, borderRings: BORDER_RINGS }).grid,
    };
}

/**
 * The address to fetch: the file's address relative to the page, plus a unique "?t=<time>" so that
 * every request is new to every cache. Uses the URL API, so it stays correct even if the address
 * ever already has a query string of its own.
 */
function freshUrl(url) {
    const base = globalThis.document?.baseURI ?? globalThis.location?.href;
    const fresh = base ? new URL(url, base) : new URL(url);
    fresh.searchParams.set(CACHE_BUST_PARAM, String(Date.now()));
    return fresh.href;
}

/**
 * True if what came back is a web page (e.g. a host's home-page fallback) rather than a level file.
 * No cell code starts with "<", so a text whose first real character is "<" can never be a level.
 * The content type is deliberately NOT used: a host that labels a good CSV as text/html (a
 * misconfigured one) must not make a perfectly good level look missing.
 */
function looksLikeWebPage(text) {
    return /^\s*</.test(text);
}

// Always gets the file as it is now:
//  - "?t=<time>" gets past every cache (browser, Cloudflare, anything in between)
//  - no-store also tells the browser not to keep or reuse a copy
//  - a web page instead of a level file counts as "missing"
//  - a server that never answers counts as an error after FETCH_TIMEOUT_MS
async function fetchText(url) {
    const controller = typeof AbortController === 'function' ? new AbortController() : null;
    const timer = controller ? setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS) : null;
    try {
        const response = await fetch(freshUrl(url), { cache: 'no-store', signal: controller?.signal });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const text = await response.text();
        if (looksLikeWebPage(text)) {
            throw new Error('the server sent a web page instead of the level file, so the file is probably missing');
        }
        return text;
    } catch (err) {
        if (err?.name === 'AbortError') throw new Error(`no answer after ${FETCH_TIMEOUT_MS / 1000} seconds`);
        throw err;
    } finally {
        if (timer) clearTimeout(timer);
    }
}

const bullets = list => list.map(m => `\n  - ${m}`).join('');

/**
 * Load levels/pandora-city-NN.csv. Returns the level, or null (after saying why in the console)
 * if the file is missing, is not a valid level file, or breaks one of the game's rules.
 */
export async function loadNumberedLevel(number, { fetchText: get = fetchText, log = console } = {}) {
    const file = levelFileName(number);
    const label = `[levels] level ${number} (${file})`;
    const fallback = 'Playing a random city instead.';

    let text;
    try { text = await get(file); }
    catch (err) { log.error(`${label} could not be loaded (${err.message}). ${fallback}`); return null; }

    const { grid, errors: parseErrors } = parseLevelCSV(text);
    if (!grid) { log.error(`${label} is not a valid level file:${bullets(parseErrors)}\n${fallback}`); return null; }

    const { errors, warnings } = validateLevel(grid);
    if (errors.length) { log.error(`${label} cannot be played:${bullets(errors)}\n${fallback}`); return null; }
    if (warnings.length) log.warn(`${label} loaded, but note:${bullets(warnings)}`);

    return { name: `Level ${number}`, makeGrid: () => grid.map(row => [...row]) };   // a copy, so nothing can change the loaded level
}

/**
 * The level to play, given the page address. Never fails: anything that cannot be used becomes a random city.
 * @param {string} search  location.search, e.g. "?22"
 * @param {Object} [options]
 * @param {(url: string) => Promise<string>} [options.fetchText]  how to get a file's text (replaceable in tests)
 * @param {{warn: Function, error: Function}} [options.log]
 * @returns {Promise<{ name: string, makeGrid: () => string[][] }>}
 */
export async function pickLevel(search, options = {}) {
    const log = options.log ?? console;
    const { number, problem } = levelNumberFromQuery(search);
    if (problem) log.warn(`[levels] ignoring the address: ${problem}. Playing a random city.`);
    if (number !== null) {
        const level = await loadNumberedLevel(number, options);
        if (level) return level;
    }
    return makeRandomCity();
}
