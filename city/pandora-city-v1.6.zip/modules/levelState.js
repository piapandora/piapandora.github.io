// levelState.js: the shared state of the level that is currently on screen.
//
// RULE: always read these through `level` ("level.reachableCells"), never copy one into a
// long-lived variable. The builder replaces some of them on every rebuild (plaza centres,
// reachable cells), and a copy taken earlier would go stale.
//
// The object is sealed, so a typo'd assignment (level.reachablCells = ...) throws instead of
// silently creating a new field.

export const level = {
    // Size of the level on screen, in cells (including the border walls). Set by the builder.
    cols: 0,
    rows: 0,

    // THREE.Box3[]: every solid thing the player bumps into (buildings, walls, galleries).
    // Written by builder.js and gallery.js; read by the controller and collectibles.js.
    obstacleColliders: [],

    // Meshes that belong to this level only; restart disposes them. Written by builder.js and gallery.js.
    // NOT cleared by reset(): the caller must dispose the meshes first, then empty this.
    dynamicMeshes: [],

    // Set of "ix,iz" keys of grid cells already taken (buildings, border, spawn zone, galleries, and the
    // cells under a special shape). Read by gallery.js, so that a gallery never goes on a taken cell.
    occupiedGridRegistry: new Set(),

    // [{x, z}] world centres of the 3x3 plazas still free for a gallery. Written by builder.js;
    // gallery.js removes a centre when it uses it; collectibles.js avoids them.
    landmarkPlazaCenters: [],

    // Set of "ix,iz" keys of cells the player can walk to from spawn. Written once per build by builder.js.
    reachableCells: new Set(),

    /** Empty everything the builder fills, ready for a new map. Does NOT touch dynamicMeshes (see above). */
    reset() {
        level.cols = 0;
        level.rows = 0;
        level.obstacleColliders.length = 0;
        level.occupiedGridRegistry.clear();
        level.landmarkPlazaCenters = [];
        level.reachableCells = new Set();
    },
};

Object.seal(level);
