// levelValidator.js: checks that a level grid is playable in Pia Parkour.
// Errors mean the level must not be used. Warnings mean it works but something looks unintended.
// Rows and columns in messages are counted from 1, like a spreadsheet.
import { SPAWN, galleriesNeeded, collectiblesCount } from './config.js';
import { CELL_SIZE, gridToWorld, spawnZoneCells } from './grid.js';
import { START, cellInfo, isSolid, reachableCells } from './levelFormat.js';

// Each pickup needs room: this many reachable open street cells per pickup, at least.
const MIN_FREE_CELLS_PER_PICKUP = 3;
const LISTED = 5;   // how many examples to name before saying "and N more"

const where = (x, z) => `row ${z + 1}, column ${x + 1}`;

/** Add one message for the first few items and a summary for the rest. */
function report(into, items, describe, summary) {
    items.slice(0, LISTED).forEach(it => into.push(describe(it)));
    if (items.length > LISTED) into.push(`...and ${items.length - LISTED} more ${summary}.`);
}

/**
 * @param {string[][]} grid  grid[row][col] of valid cell codes (see parseLevelCSV)
 * @param {{x:number,z:number}} [options.spawn]  where the player starts (world coordinates)
 * @returns {{ errors: string[], warnings: string[] }}
 */
export function validateLevel(grid, { spawn = SPAWN } = {}) {
    const errors = [], warnings = [];
    const rows = grid.length, cols = grid[0].length;
    const at = (x, z) => (grid[z] && grid[z][x]) || null;

    // ---- every cell must be a code the game knows (the CSV reader already refuses others; this keeps a
    // grid made some other way, by a tool or by hand, from crashing the checks below) ----
    const unknown = [];
    grid.forEach((row, z) => row.forEach((code, x) => { if (cellInfo(code) === null) unknown.push({ x, z, code }); }));
    if (unknown.length) {
        report(errors, unknown, c => `${where(c.x, c.z)} is "${c.code}", which is not a cell code the game can build.`, 'unknown cell codes');
        return { errors, warnings };
    }

    // ---- the player's start: the cells at the centre of the map must be "S", and only those ----
    const zone = spawnZoneCells(cols, rows, spawn);
    const zoneKeys = new Set(zone.map(c => `${c.x},${c.z}`));
    const startCells = `${zone.length} cell${zone.length === 1 ? '' : 's'}`;
    let zoneOk = zone.length > 0;
    if (zone.length === 0) {
        errors.push('The map is too small: there is no start area around its centre.');
    } else {
        const wrong = zone.filter(c => grid[c.z][c.x] !== START);
        if (wrong.length) {
            zoneOk = false;
            report(errors, wrong,
                c => `The player starts at the centre of the map, so ${where(c.x, c.z)} must be "S" (the start), but it is "${grid[c.z][c.x]}".`,
                'start cells that are not "S"');
        }
        const stray = [];
        grid.forEach((row, z) => row.forEach((code, x) => { if (code === START && !zoneKeys.has(`${x},${z}`)) stray.push({ x, z }); }));
        report(errors, stray,
            c => `The "S" at ${where(c.x, c.z)} is outside the start area. "S" marks only the ${startCells} at the centre of the map where the player starts.`,
            'stray "S" cells');
    }

    // ---- plazas: every P needs N on all 8 sides, every N belongs to exactly one P ----
    const centres = [];
    grid.forEach((row, z) => row.forEach((code, x) => { if (code === 'P') centres.push({ x, z }); }));
    // The first of the 8 neighbours that is not an "N", or null if the plaza is complete
    const firstMissingNeighbour = c => {
        for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
            if ((dx || dz) && at(c.x + dx, c.z + dz) !== 'N') return { x: c.x + dx, z: c.z + dz };
        }
        return null;
    };
    const broken = [];
    for (const c of centres) {
        const bad = firstMissingNeighbour(c);
        if (bad) broken.push({ c, bad });
    }
    report(errors, broken,
        ({ c, bad }) => `The plaza centre "P" at ${where(c.x, c.z)} must have "N" on all 8 sides, but ${bad.x < 0 || bad.z < 0 || bad.x >= cols || bad.z >= rows ? 'the map ends there' : `${where(bad.x, bad.z)} is "${at(bad.x, bad.z)}"`}.`,
        'broken plazas');
    const strayN = [], overlapping = [];
    grid.forEach((row, z) => row.forEach((code, x) => {
        if (code !== 'N') return;
        let near = 0;
        for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if (at(x + dx, z + dz) === 'P') near++;
        if (near === 0) strayN.push({ x, z }); else if (near > 1) overlapping.push({ x, z });
    }));
    report(errors, strayN, c => `The "N" at ${where(c.x, c.z)} is not next to a plaza centre "P". Plazas are a "P" with "N" all around it.`, 'stray "N" cells');
    report(errors, overlapping, c => `The "N" at ${where(c.x, c.z)} touches two plaza centres. Plazas must not overlap.`, 'overlapping plaza cells');

    const needed = galleriesNeeded;
    if (centres.length < needed) {
        errors.push(`The level has ${centres.length} plaza${centres.length === 1 ? '' : 's'} but a full game needs ${needed}, one per gallery. With fewer, galleries would land on ordinary streets and could block the way.`);
    }

    // ---- walkable space (only meaningful once the start area is open) ----
    if (zoneOk) {
        const reach = reachableCells(grid, zone);

        // A plaza that is walled in cannot hold a gallery, so only plazas the player can walk to count
        const usablePlazas = centres.filter(c => reach.has(`${c.x},${c.z}`)).length;
        if (centres.length >= needed && usablePlazas < needed) {
            errors.push(`Only ${usablePlazas} of the ${centres.length} plazas can be reached from the start, but a full game needs ${needed}. A walled-in plaza cannot hold a gallery.`);
        }
        const pickupCells = [];   // reachable ground where a pickup can appear
        reach.forEach(key => {
            const [x, z] = key.split(',').map(Number);
            const info = cellInfo(grid[z][x]);
            if (info.storeys > 0 || info.plaza) return;
            if (Math.abs(gridToWorld(x, cols) - spawn.x) <= CELL_SIZE && Math.abs(gridToWorld(z, rows) - spawn.z) <= CELL_SIZE) return;
            pickupCells.push(key);
        });
        const wanted = collectiblesCount * MIN_FREE_CELLS_PER_PICKUP;
        if (pickupCells.length < wanted) {
            errors.push(`Only ${pickupCells.length} open street cells can be reached from the start; at least ${wanted} are needed so the ${collectiblesCount} pickups have room.`);
        }

        const cut = [];
        grid.forEach((row, z) => row.forEach((code, x) => { if (!isSolid(code) && !reach.has(`${x},${z}`)) cut.push({ x, z }); }));
        if (cut.length) {
            warnings.push(`${cut.length} open cell${cut.length === 1 ? '' : 's'} cannot be reached from the start (for example ${where(cut[0].x, cut[0].z)}). Nothing will appear there.`);
        }
    }

    // ---- things that work but look unintended ----
    let openEdge = 0;
    for (let z = 0; z < rows; z++) for (let x = 0; x < cols; x++) {
        if ((x === 0 || z === 0 || x === cols - 1 || z === rows - 1) && grid[z][x] !== 'W') openEdge++;
    }
    if (openEdge) warnings.push(`The outer edge of the map is not fully walled (${openEdge} cell${openEdge === 1 ? ' is' : 's are'} not "W"). Players can walk right to the edge.`);

    const future = grid.flat().filter(code => /^[QL]$/.test(code)).length;
    if (future) warnings.push(`${future} cell${future === 1 ? ' uses' : 's use'} the codes Q or L. These are plain open ground in Pia Parkour for now.`);

    return { errors, warnings };
}
