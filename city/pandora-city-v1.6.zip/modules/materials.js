// materials.js: world textures and materials, plus poster materials for gallery boxes
import * as THREE from 'three';

const textureLoader = new THREE.TextureLoader();

function setupTex(tex) {
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.generateMipmaps = true;
    tex.minFilter = THREE.LinearMipmapLinearFilter;
    tex.magFilter = THREE.LinearFilter;
    tex.needsUpdate = true;
    tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
}

// The ground floor of a building depends on how many storeys it has: ground-floor-1.png for a
// 1-storey building, ground-floor-2.png for 2 storeys, and so on. The last image is used for that
// many storeys or more (6 and above), so taller buildings in CSV maps still get a ground floor.
// To add an image for another height, add one more number to this list.
const GROUND_FLOOR_FILES = [1, 2, 3, 4, 5, 6].map(n => `images/ground-floor-${n}.png`);

// If an image has not been added yet, buildings of that height borrow the image for the height below
// and the console says so, instead of showing blank walls. This runs once every image has either
// loaded or failed, going upwards, so two missing images in a row still end up with a picture.
const groundFloorLoaded = [];
let groundFloorSettled = 0;
function groundFloorSettledOne(index, loaded) {
    groundFloorLoaded[index] = loaded;
    if (++groundFloorSettled < GROUND_FLOOR_FILES.length) return;
    GROUND_FLOOR_FILES.forEach((file, i) => {
        if (groundFloorLoaded[i]) return;
        if (i === 0) { console.warn(`${file} was not found.`); return; }
        const heights = i === GROUND_FLOOR_FILES.length - 1 ? `${i + 1}+` : `${i + 1}`;
        console.warn(`${file} was not found, so buildings of ${heights} storeys use ${GROUND_FLOOR_FILES[i - 1]} for now.`);
        groundMaterials[i].map = groundMaterials[i - 1].map;
        groundMaterials[i].needsUpdate = true;
    });
}

const groundTextures = GROUND_FLOOR_FILES.map((file, i) => textureLoader.load(
    file,
    tex => { setupTex(tex); groundFloorSettledOne(i, true); },
    undefined,
    () => groundFloorSettledOne(i, false)
));

// groundMaterials[0] is for 1-storey buildings, [1] for 2 storeys, and so on.
export const groundMaterials = groundTextures.map(map => new THREE.MeshLambertMaterial({ map }));

/** The ground-floor material for a building with this many storeys. */
export function groundMaterialFor(storeys) {
    return groundMaterials[Math.max(1, Math.min(storeys, groundMaterials.length)) - 1];
}

const upperTexture = textureLoader.load('images/upper-floor.png', setupTex);
const roofTexture = textureLoader.load('images/roof.png', setupTex);
const landmarkTexture = textureLoader.load('images/landmark.png', setupTex);
const wallTexture = textureLoader.load('images/wall.png', setupTex);

// The fallback poster card uses the interface accent colour, which lives in style.css (--accent), so there is one
// place to change it. If the page styles cannot be read (the tests) the card is drawn in white.
function accentColour() {
    try {
        const value = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim();
        if (value) return value;
    } catch (e) { /* no page styles here */ }
    return '#ffffff';
}
const accent = accentColour();

const posterCanvas = document.createElement('canvas');
posterCanvas.width = posterCanvas.height = 512;
const pCtx = posterCanvas.getContext('2d');
pCtx.fillStyle = '#1a1a24'; pCtx.fillRect(0, 0, 512, 512);
pCtx.strokeStyle = accent; pCtx.lineWidth = 16; pCtx.strokeRect(32, 32, 448, 448);
pCtx.fillStyle = accent; pCtx.font = 'bold 42px sans-serif'; pCtx.textAlign = 'center';
pCtx.fillText("GALLERY POSTER", 256, 256);
const posterFallbackTexture = new THREE.CanvasTexture(posterCanvas);
posterFallbackTexture.colorSpace = THREE.SRGBColorSpace;
export const fallbackMaterial = new THREE.MeshBasicMaterial({ map: posterFallbackTexture });

// A poster picture comes from another website, and a download can fail for a passing reason (a server
// hiccup, a dropped connection) even though the file is fine. So a failed poster is tried again after a
// short wait, and only when every try has failed does it show the "GALLERY POSTER" card, instead of
// staying blank for the rest of the game. These are the waits, in milliseconds, before retry 1 and retry 2.
export const POSTER_RETRY_DELAYS_MS = [1500, 4000];

// Every poster is kept here for the whole game, so a picture is only ever downloaded once (restart relies
// on this: it frees the old level's meshes but never these shared materials).
export const posterMatCache = new Map();
export function loadPosterMaterial(filename) {
    if (!filename) return fallbackMaterial;
    if (posterMatCache.has(filename)) return posterMatCache.get(filename);
    const mat = new THREE.MeshBasicMaterial({});
    posterMatCache.set(filename, mat);
    const attempt = (n) => {
        mat.map = textureLoader.load(filename, (loadedTex) => {
            loadedTex.colorSpace = THREE.SRGBColorSpace;
            loadedTex.needsUpdate = true;
        }, undefined, () => {
            if (n < POSTER_RETRY_DELAYS_MS.length) {
                console.warn(`${filename} did not download, trying again in ${POSTER_RETRY_DELAYS_MS[n] / 1000} s.`);
                setTimeout(() => attempt(n + 1), POSTER_RETRY_DELAYS_MS[n]);
            } else {
                console.warn(`${filename} did not download after ${n + 1} tries, so the gallery poster card is shown instead.`);
                mat.map = fallbackMaterial.map;
                mat.needsUpdate = true;
            }
        });
        if (n > 0) mat.needsUpdate = true;     // a new picture is being swapped in on a material that may already be on screen
    };
    attempt(0);
    return mat;
}

export const upperMaterial = new THREE.MeshLambertMaterial({ map: upperTexture });
export const roofMaterial = new THREE.MeshLambertMaterial({ map: roofTexture });
export const landmarkMaterial = new THREE.MeshLambertMaterial({ map: landmarkTexture });
export const wallMaterial = new THREE.MeshLambertMaterial({ map: wallTexture });