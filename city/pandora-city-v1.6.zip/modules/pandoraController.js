import { EventDispatcher, Euler, Vector2, Vector3, Quaternion } from 'three';

/**
 * PandoraController - first-person pointer-lock controller with walking physics.
 *
 * Usage (mirrors the OrbitControls / PointerLockControls lifecycle):
 *
 *   const controls = new PandoraController(camera, renderer.domElement, { ...options });
 *   controls.addEventListener('lock',   () => hideMenu());
 *   controls.addEventListener('unlock', () => showMenu());
 *   menuButton.onclick = () => controls.lock();
 *
 *   // every frame:
 *   controls.update(deltaSeconds);
 *
 *   // when finished:
 *   controls.dispose();
 *
 * Events: 'lock', 'unlock', 'lockerror' (the browser refused the pointer lock), 'change' (camera
 * moved/turned during update), 'jump'.
 *
 * World interaction is kept out of the controller. Pass `colliders` (THREE.Box3-like
 * objects with min/max) for the built-in cylinder-vs-box collision, or supply your own
 * `resolveHorizontal(controller)` / `resolveVertical(controller, prevY)` callbacks.
 */

/*
 * ============================================================================
 *  HOW THIS WORKS  (a plain-language guide for whoever edits this next)
 * ============================================================================
 *
 *  THE BIG IDEA
 *  The controller owns the PLAYER (where you are, where you look, how you move).
 *  Your GAME owns the WORLD (what is solid, what gets collected, menus, score).
 *  They talk through a few small doors: options going in, events coming out,
 *  and a handful of properties/methods. Keep game rules out of this file.
 *
 *  THE THREE "ARE WE ON?" FLAGS  (easy to confuse)
 *    enabled      master switch. false = controller does nothing at all.
 *    isLocked     true while the mouse pointer is captured by the page. Set by the
 *                 browser, not by you. update() does nothing unless this is true.
 *    inputLocked  true = ignore the player's keys/buttons, but physics still runs
 *                 (used when the game is won: you coast to a stop, can't steer).
 *
 *  WHAT HAPPENS EACH FRAME  (update(delta), in this order)
 *    1. LOOK      buffered mouse movement is spike-filtered, added to a TARGET
 *                 yaw/pitch, and the real view glides toward it (lookSmoothing).
 *                 Camera orientation is set from yaw+pitch using 'YXZ' order
 *                 (yaw first, then pitch). That order is what stops the horizon tilting.
 *    2. FORCES    velocity is damped (friction), gravity pulls down, and held
 *                 keys push the velocity in the direction you're facing.
 *    3. MOVE      position moves sideways in small sub-steps (so fast movement
 *                 can't skip through a thin wall). After each sub-step: clamp to
 *                 `bounds`, then push out of any colliders and slide along walls.
 *    4. VERTICAL  position moves up/down, then: floor stops you, `maxHeight`
 *                 caps you, and box tops/undersides are landed on / bonked.
 *    5. REPORT    if the camera actually moved or turned, a 'change' event fires
 *                 and update() returns true.
 *
 *  UNITS AND CONVENTIONS
 *    Metres and seconds. Position is the EYE (camera), not the feet:
 *    feet = position.y - playerHeight. Yaw 0 faces -Z. `maxHeight` limits FEET height.
 *    Keys are matched by event.code (physical key position), so W/A/S/D works on
 *    any keyboard layout, including AZERTY.
 *
 *  THE FEEL KNOBS  (what to change for "I want it to feel different")
 *    walkSpeed / runSpeed   how fast you can go.
 *    acceleration, damping  how quickly you speed up / slow down. Top speed is
 *                           speed * acceleration / damping, so 10/10 gives
 *                           exactly `speed`. Lower damping = icier, floatier.
 *    gravity, jumpForce, maxJumps   jump height and number of air jumps.
 *    lookSpeed              mouse sensitivity (radians per mouse count).
 *    lookSmoothing          1 = raw/instant mouse, lower = smoother but laggier.
 *                           Frame-rate independent (0.66 at 60 fps = same at 144).
 *
 *  GAME-SPECIFIC BEHAVIOUR  (all optional, set to null to switch off)
 *    teleportKey ('Enter'), runMouseButton (0 = left click), runMode ('hold'|'toggle'),
 *    keys (remap any action to one or more KeyboardEvent.code values).
 *
 *  HOW THE WORLD PLUGS IN
 *    colliders: an array (or a function returning an array) of box-like objects
 *      with .min and .max {x,y,z}, e.g. THREE.Box3. The player is a vertical
 *      cylinder (playerRadius x playerHeight). Use a function if your array can
 *      be replaced/rebuilt, so the controller always sees the current one.
 *    resolveHorizontal / resolveVertical: provide your own functions to replace
 *      the built-in box collision (e.g. for slopes or a physics engine). They
 *      receive the controller and may change position and velocity directly.
 *    Events out: 'lock', 'unlock', 'lockerror', 'jump', 'change'.
 *
 *  LIFECYCLE
 *    new PandoraController(camera, el, opts)  attaches listeners
 *    controls.lock()                          must be called from a user click
 *    controls.update(delta)                   once per frame
 *    controls.dispose()                       removes every listener (call it
 *                                             when tearing the game down)
 *
 *  GOTCHAS WORTH KNOWING
 *    - update() returns early unless the pointer is locked. If nothing moves,
 *      check isLocked first.
 *    - delta is clamped to maxDelta (0.05s) so a lag spike or a backgrounded tab
 *      can't launch you through a wall. The game slows down instead of jumping.
 *    - teleport() zeroes velocity and jump count. teleportToSpawn() also resets
 *      the view direction.
 *    - Landing on a box needs your feet to have been at/above its top on the
 *      previous frame (see LAND_BELOW / LAND_ABOVE). Walking off a ledge is fine;
 *      clipping through its side while falling will not land you.
 *    - Key release is always honoured even when inputLocked, so a key can never
 *      get "stuck" held down after a win screen or alt-tab.
 *    - Everything the controller needs lives on the instance, so you can have
 *      more than one (e.g. split screen) without them interfering.
 *
 *  SAFE WAY TO CHANGE THIS FILE
 *    Commit first. Change one thing. Play for a minute (walk, run, double-jump,
 *    bump a wall, land on a box, open and close the menu). If an LLM edits this,
 *    ask for a small diff rather than a rewrite.
 * ============================================================================
 */

const _euler = new Euler(0, 0, 0, 'YXZ');
const EPS = 1e-6;

// Vertical landing tolerances (metres), carried over from the original game code.
const LAND_BELOW = 0.05;  // feet must have started at/above (top - this) to land on a box
const LAND_ABOVE = 0.1;   // ...and end no higher than (top + this)

const DEFAULT_KEYS = {
    forward: ['KeyW'],
    backward: ['KeyS'],
    left: ['KeyA'],
    right: ['KeyD'],
    run: ['ShiftLeft', 'ShiftRight'],
    jump: ['Space'],
};

const DEFAULT_MOUSE_FILTER = {
    enabled: true,
    abs: 300,    // a frame must exceed this many counts to count as a spike...
    ratio: 4,    // ...and be this many times the last accepted frame
    floor: 25,   // minimum "recent motion" used for the ratio
    log: false,  // console.warn each dropped spike
};

export class PandoraController extends EventDispatcher {

    /**
     * @param {THREE.Object3D} object - Usually the camera. Its position and quaternion are driven.
     * @param {HTMLElement|null} domElement - Element used for pointer lock (renderer.domElement).
     *        Pass null to construct without listeners and call connect(el) later.
     * @param {Object} [options]
     */
    constructor(object, domElement = null, options = {}) {
        super();

        this.object = object;
        this.domElement = null;

        // ---- Public state -------------------------------------------------
        this.enabled = true;       // master switch (like OrbitControls.enabled)
        this.isLocked = false;     // true while the pointer is locked to domElement
        this.inputLocked = false;  // true = keep physics running but ignore player input
        this.velocity = new Vector3();
        this.jumpCount = 0;

        /** Held-input state. Read-only for consumers; use resetInput() to clear it. */
        this.input = { forward: false, backward: false, left: false, right: false, run: false, mouseRun: false };

        // ---- Configuration (all overridable via options) -------------------
        const o = options;
        this.playerHeight = o.playerHeight ?? 1.6;     // eye height above the feet
        this.playerRadius = o.playerRadius ?? 0.45;
        this.floorHeight = o.floorHeight ?? 0;         // world Y of the ground plane
        this.maxHeight = o.maxHeight ?? Infinity;      // highest allowed FEET height
        this.bounds = o.bounds ?? null;                // { minX, maxX, minZ, maxZ } or null
        this.spawn = { x: 0, y: null, z: 0, ...(o.spawn ?? {}) }; // y null = standing on floor

        this.gravity = o.gravity ?? 25.0;
        this.jumpForce = o.jumpForce ?? 12.5;
        this.maxJumps = o.maxJumps ?? 2;

        this.walkSpeed = o.walkSpeed ?? 20 / 3;
        this.runSpeed = o.runSpeed ?? 10.0;
        // Terminal speed = speed * acceleration / damping (10/10 = exactly `speed` by default).
        this.acceleration = o.acceleration ?? 10.0;
        this.damping = o.damping ?? 10.0;

        this.lookSpeed = o.lookSpeed ?? 0.001;         // radians per mouse count
        this.lookSmoothing = o.lookSmoothing ?? 0.66;  // lerp factor at 60 fps (1 = no smoothing)
        this.maxPitch = o.maxPitch ?? Math.PI / 2;

        this.maxDelta = o.maxDelta ?? 0.05;            // update() clamps delta to this
        this.maxStepDistance = o.maxStepDistance ?? 0.2; // horizontal sub-step size (anti-tunnelling)

        // Game-flavoured bindings. Set to null to disable.
        this.teleportKey = o.teleportKey === undefined ? 'Enter' : o.teleportKey;
        this.runMouseButton = o.runMouseButton === undefined ? 0 : o.runMouseButton;
        // 'hold': run while the key/button is held. 'toggle': each press flips run on/off
        // (easier on hands for long sessions). Change at runtime with setRunMode().
        this.runMode = o.runMode === 'toggle' ? 'toggle' : 'hold';

        this.mouseFilter = { ...DEFAULT_MOUSE_FILTER, ...(o.mouseFilter ?? {}) };

        // Collision. `colliders` may be an array or a function returning one.
        this.colliders = o.colliders ?? [];
        this.resolveHorizontal = o.resolveHorizontal ?? null;
        this.resolveVertical = o.resolveVertical ?? null;

        this.setKeys({ ...DEFAULT_KEYS, ...(o.keys ?? {}) });

        // ---- Internal look state -------------------------------------------
        this._target = new Vector2(0, 0);   // x = yaw, y = pitch
        this._current = new Vector2(0, 0);
        this._pendingMouse = { x: 0, y: 0 };
        this._lastAcceptedMag = 0;

        this._onMouseMove = this._onMouseMove.bind(this);
        this._onKeyDown = this._onKeyDown.bind(this);
        this._onKeyUp = this._onKeyUp.bind(this);
        this._onMouseDown = this._onMouseDown.bind(this);
        this._onMouseUp = this._onMouseUp.bind(this);
        this._onBlur = this._onBlur.bind(this);
        this._onPointerLockChange = this._onPointerLockChange.bind(this);
        this._onPointerLockError = this._onPointerLockError.bind(this);

        // Seed look state from the object's current orientation.
        _euler.setFromQuaternion(object.quaternion, 'YXZ');
        this._target.set(_euler.y, _euler.x);
        this._current.copy(this._target);

        this._lastPosition = new Vector3().copy(object.position);
        this._lastQuaternion = new Quaternion().copy(object.quaternion);

        if (domElement) this.connect(domElement);
    }

    // ------------------------------------------------------------------ setup

    /** Attach DOM listeners. Called automatically if a domElement was passed to the constructor. */
    connect(domElement) {
        if (this.domElement) this.disconnect();
        this.domElement = domElement;
        const doc = domElement.ownerDocument;
        const win = doc.defaultView;

        doc.addEventListener('mousemove', this._onMouseMove);
        doc.addEventListener('keydown', this._onKeyDown);
        doc.addEventListener('keyup', this._onKeyUp);
        doc.addEventListener('mousedown', this._onMouseDown);
        doc.addEventListener('mouseup', this._onMouseUp);
        doc.addEventListener('pointerlockchange', this._onPointerLockChange);
        doc.addEventListener('pointerlockerror', this._onPointerLockError);
        win.addEventListener('blur', this._onBlur);

        this.isLocked = doc.pointerLockElement === domElement;
    }

    /** Detach DOM listeners and release the pointer. Safe to call repeatedly. */
    disconnect() {
        const el = this.domElement;
        if (!el) return;
        const doc = el.ownerDocument;
        const win = doc.defaultView;

        doc.removeEventListener('mousemove', this._onMouseMove);
        doc.removeEventListener('keydown', this._onKeyDown);
        doc.removeEventListener('keyup', this._onKeyUp);
        doc.removeEventListener('mousedown', this._onMouseDown);
        doc.removeEventListener('mouseup', this._onMouseUp);
        doc.removeEventListener('pointerlockchange', this._onPointerLockChange);
        doc.removeEventListener('pointerlockerror', this._onPointerLockError);
        win?.removeEventListener('blur', this._onBlur);

        if (doc.pointerLockElement === el) doc.exitPointerLock();
        this.isLocked = false;
        this.resetInput();
        this.domElement = null;
    }

    dispose() {
        this.disconnect();
    }

    /** Replace the key bindings. Each action maps to an array of KeyboardEvent.code strings. */
    setKeys(keys) {
        this.keys = keys;
        this._keyMap = new Map();
        for (const [action, codes] of Object.entries(keys)) {
            for (const code of codes) this._keyMap.set(code, action);
        }
    }

    // ------------------------------------------------------------- public API

    lock() {
        // Newer browsers return a promise, and the browser REJECTS it when it refuses the lock (for example when
        // it is requested right after the player pressed Esc). The 'lockerror' event below reports that, so the
        // rejection itself is swallowed here instead of showing up as an uncaught error.
        const request = this.domElement?.requestPointerLock();
        if (request && typeof request.catch === 'function') request.catch(() => {});
    }

    unlock() {
        this.domElement?.ownerDocument.exitPointerLock();
    }

    get position() {
        return this.object.position;
    }

    /** True when standing on something (floor or a collider top) and not mid-jump. */
    get isGrounded() {
        return this.velocity.y === 0 && this.jumpCount === 0;
    }

    get yaw() { return this._current.x; }
    get pitch() { return this._current.y; }

    /** Instantly set the view direction (radians). Yaw 0 faces -Z. */
    setLook(yaw, pitch = 0) {
        this._target.set(yaw, this._clampPitch(pitch));
        this._current.copy(this._target);
        _euler.set(this._current.y, this._current.x, 0);
        this.object.quaternion.setFromEuler(_euler);
    }

    /** Move the player (eye position is placed standing on the floor unless y is given). */
    teleport(x, z, y = this.floorHeight + this.playerHeight) {
        this.object.position.set(x, y, z);
        this.velocity.set(0, 0, 0);
        this.jumpCount = 0;
    }

    teleportToSpawn() {
        this.teleport(this.spawn.x, this.spawn.z, this.spawn.y ?? undefined);
        this.setLook(0, 0);
    }

    /** Switch between 'hold' and 'toggle' running (safe to call at any time, e.g. from a settings menu). */
    setRunMode(mode) {
        this.runMode = mode === 'toggle' ? 'toggle' : 'hold';
        this.input.run = false;
        this.input.mouseRun = false;
    }

    /** Clear all held keys/buttons and any buffered mouse movement. */
    resetInput() {
        const i = this.input;
        i.forward = i.backward = i.left = i.right = i.run = i.mouseRun = false;
        this._pendingMouse.x = this._pendingMouse.y = 0;
    }

    /**
     * Advance look + physics. Call once per frame.
     * @param {number} delta - seconds since last frame (clamped to maxDelta)
     * @returns {boolean} true if the object moved or turned this frame
     */
    update(delta) {
        if (!this.enabled || !this.isLocked) return false;
        delta = Math.min(delta, this.maxDelta);
        if (!(delta > 0)) return false;

        const obj = this.object;
        const pos = obj.position;
        const v = this.velocity;

        // ---- Look (frame-rate independent smoothing) ----
        this._applyPendingMouse();
        this._current.lerp(this._target, 1 - Math.pow(1 - this.lookSmoothing, delta * 60));
        _euler.set(this._current.y, this._current.x, 0);
        obj.quaternion.setFromEuler(_euler);

        // ---- Horizontal acceleration / damping ----
        v.x -= v.x * this.damping * delta;
        v.z -= v.z * this.damping * delta;
        v.y -= this.gravity * delta;

        const yaw = this._current.x;
        const fwdX = -Math.sin(yaw), fwdZ = -Math.cos(yaw);
        const rightX = Math.cos(yaw), rightZ = -Math.sin(yaw);

        const inp = this.input;
        let inputX = Number(inp.right) - Number(inp.left);
        let inputZ = Number(inp.forward) - Number(inp.backward);
        const inputLen = Math.hypot(inputX, inputZ);
        if (inputLen > 0) { inputX /= inputLen; inputZ /= inputLen; }

        const speed = (inp.run || inp.mouseRun) ? this.runSpeed : this.walkSpeed;
        const accel = speed * this.acceleration * delta;
        v.x += (rightX * inputX + fwdX * inputZ) * accel;
        v.z += (rightZ * inputX + fwdZ * inputZ) * accel;

        // ---- Horizontal movement, sub-stepped so fast movement can't tunnel ----
        const steps = Math.max(1, Math.ceil(Math.hypot(v.x, v.z) * delta / this.maxStepDistance));
        for (let s = 0; s < steps; s++) {
            pos.x += v.x * delta / steps;
            pos.z += v.z * delta / steps;

            const b = this.bounds;
            if (b) {
                pos.x = Math.max(b.minX, Math.min(b.maxX, pos.x));
                pos.z = Math.max(b.minZ, Math.min(b.maxZ, pos.z));
            }

            if (this.resolveHorizontal) this.resolveHorizontal(this);
            else this._resolveHorizontalBoxes();
        }

        // ---- Vertical movement ----
        const prevY = pos.y;
        pos.y += v.y * delta;

        const minEye = this.floorHeight + this.playerHeight;
        if (pos.y < minEye) {
            v.y = 0;
            pos.y = minEye;
            this.jumpCount = 0;
        }
        const maxEye = this.maxHeight + this.playerHeight;
        if (pos.y > maxEye) {
            pos.y = maxEye;
            if (v.y > 0) v.y = 0;
        }

        if (this.resolveVertical) this.resolveVertical(this, prevY);
        else this._resolveVerticalBoxes(prevY);

        // ---- Change detection (same pattern as OrbitControls) ----
        if (this._lastPosition.distanceToSquared(pos) > EPS ||
            8 * (1 - this._lastQuaternion.dot(obj.quaternion)) > EPS) {
            this._lastPosition.copy(pos);
            this._lastQuaternion.copy(obj.quaternion);
            this.dispatchEvent({ type: 'change' });
            return true;
        }
        return false;
    }

    // --------------------------------------------------------- built-in collision

    _getColliders() {
        const c = typeof this.colliders === 'function' ? this.colliders() : this.colliders;
        return c || [];
    }

    /** Vertical cylinder (radius, height) pushed out of axis-aligned boxes; velocity slides along walls. */
    _resolveHorizontalBoxes() {
        const boxes = this._getColliders();
        if (boxes.length === 0) return;

        const pos = this.object.position;
        const v = this.velocity;
        const r = this.playerRadius;

        for (let iter = 0; iter < 3; iter++) {
            for (const box of boxes) {
                const px = pos.x, pz = pos.z, py = pos.y;
                const feet = py - this.playerHeight;
                const head = py;

                if (head <= box.min.y || feet >= box.max.y - LAND_BELOW) continue;

                const closestX = Math.max(box.min.x, Math.min(px, box.max.x));
                const closestZ = Math.max(box.min.z, Math.min(pz, box.max.z));
                const dx = px - closestX, dz = pz - closestZ;
                const distSq = dx * dx + dz * dz;
                if (distSq >= r * r) continue;

                let nx = 0, nz = 0;
                const dist = Math.sqrt(distSq);
                if (dist > 0) {
                    nx = dx / dist; nz = dz / dist;
                    pos.x += nx * (r - dist);
                    pos.z += nz * (r - dist);
                } else {
                    // Centre is inside the box: push out through the nearest face.
                    const toMinX = px - box.min.x, toMaxX = box.max.x - px;
                    const toMinZ = pz - box.min.z, toMaxZ = box.max.z - pz;
                    const m = Math.min(toMinX, toMaxX, toMinZ, toMaxZ);
                    if (m === toMinX)      { nx = -1; nz = 0; pos.x = box.min.x - r; }
                    else if (m === toMaxX) { nx = 1;  nz = 0; pos.x = box.max.x + r; }
                    else if (m === toMinZ) { nx = 0;  nz = -1; pos.z = box.min.z - r; }
                    else                   { nx = 0;  nz = 1;  pos.z = box.max.z + r; }
                }
                const dot = v.x * nx + v.z * nz;
                if (dot < 0) { v.x -= nx * dot; v.z -= nz * dot; }
            }
        }
    }

    /** Land on box tops / bonk heads on box undersides. */
    _resolveVerticalBoxes(prevY) {
        const boxes = this._getColliders();
        if (boxes.length === 0) return;

        const pos = this.object.position;
        const v = this.velocity;
        const r = this.playerRadius;
        const h = this.playerHeight;

        const px = pos.x, pz = pos.z, py = pos.y;
        const feet = py - h, prevFeet = prevY - h;

        for (const box of boxes) {
            const lx = Math.max(box.min.x, Math.min(px, box.max.x));
            const lz = Math.max(box.min.z, Math.min(pz, box.max.z));
            if ((px - lx) * (px - lx) + (pz - lz) * (pz - lz) > r * r) continue;

            if (v.y <= 0 && prevFeet >= box.max.y - LAND_BELOW && feet <= box.max.y + LAND_ABOVE) {
                v.y = 0;
                pos.y = box.max.y + h;
                this.jumpCount = 0;
            } else if (v.y > 0 && prevY <= box.min.y && py >= box.min.y) {
                v.y = 0;
                pos.y = box.min.y;
            }
        }
    }

    // ------------------------------------------------------------------ input

    _clampPitch(p) {
        return Math.max(-this.maxPitch, Math.min(this.maxPitch, p));
    }

    /**
     * Mouse input is summed per frame and passed through a spike filter before it turns the
     * camera. A lone frame of huge movement after calm input (observed: ~550-650 counts) is dropped.
     */
    _applyPendingMouse() {
        const dx = this._pendingMouse.x, dy = this._pendingMouse.y;
        this._pendingMouse.x = this._pendingMouse.y = 0;

        const f = this.mouseFilter;
        const mag = Math.hypot(dx, dy);
        if (f.enabled && mag > f.abs && mag > f.ratio * Math.max(this._lastAcceptedMag, f.floor)) {
            if (f.log) console.warn('[mouse-filter] dropped spike', { dx, dy, lastAccepted: +this._lastAcceptedMag.toFixed(1) });
            return;
        }
        this._lastAcceptedMag = mag;
        this._target.x -= dx * this.lookSpeed;
        this._target.y = this._clampPitch(this._target.y - dy * this.lookSpeed);
    }

    _onMouseMove(e) {
        if (!this.isLocked || !this.enabled) return;
        this._pendingMouse.x += e.movementX;
        this._pendingMouse.y += e.movementY;
    }

    _onKeyDown(e) {
        if (!this.enabled || !this.isLocked || this.inputLocked) return;

        if (this.teleportKey && e.code === this.teleportKey) {
            this.teleportToSpawn();
            return;
        }

        const action = this._keyMap.get(e.code);
        if (!action) return;

        if (action === 'jump') {
            e.preventDefault(); // stop Space from scrolling / clicking focused buttons
            if (!e.repeat && this.jumpCount < this.maxJumps) {
                this.velocity.y = this.jumpForce;
                this.jumpCount++;
                this.dispatchEvent({ type: 'jump', count: this.jumpCount });
            }
            return;
        }
        if (action === 'run' && this.runMode === 'toggle') {
            if (!e.repeat) this.input.run = !this.input.run;
            return;
        }
        this.input[action] = true;
    }

    _onKeyUp(e) {
        // Intentionally ignores lock/inputLocked state so keys can never get stuck down.
        const action = this._keyMap.get(e.code);
        if (!action || action === 'jump') return;
        if (action === 'run' && this.runMode === 'toggle') return; // toggle ignores release
        this.input[action] = false;
    }

    _onMouseDown(e) {
        if (this.runMouseButton !== null && e.button === this.runMouseButton &&
            this.enabled && this.isLocked && !this.inputLocked) {
            if (this.runMode === 'toggle') this.input.run = !this.input.run; // shares the key's toggle
            else this.input.mouseRun = true;
        }
    }

    _onMouseUp(e) {
        if (this.runMouseButton !== null && e.button === this.runMouseButton && this.runMode === 'hold') {
            this.input.mouseRun = false;
        }
    }

    _onBlur() {
        this.resetInput();
    }

    _onPointerLockChange() {
        const locked = this.domElement.ownerDocument.pointerLockElement === this.domElement;
        if (locked === this.isLocked) return;
        this.isLocked = locked;

        this._pendingMouse.x = this._pendingMouse.y = 0;
        this._lastAcceptedMag = 0;

        if (locked) {
            this.dispatchEvent({ type: 'lock' });
        } else {
            this.resetInput();
            this.dispatchEvent({ type: 'unlock' });
        }
    }

    _onPointerLockError() {
        console.error('PandoraController: unable to use Pointer Lock API');
        this.dispatchEvent({ type: 'lockerror' });
    }
}