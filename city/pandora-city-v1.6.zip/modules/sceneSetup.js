// sceneSetup.js: scene, lights, sky, camera, renderer, and window-resize handling
import * as THREE from 'three';
import { HDRLoader } from 'three/addons/loaders/HDRLoader.js';
import { SPAWN, FLOOR_Y } from './config.js';
import { createSky } from './sky.js';
import { createShuffleBag } from './shuffleBag.js';

// ==========================================
// THE LOOK: the settings you are most likely to change
// ==========================================

// --- Light ---
// The scene is lit by a hemisphere light plus an optional sun.
// The hemisphere light: LIGHT_SKY_COLOUR comes from above (roofs and streets get exactly this), LIGHT_GROUND_COLOUR
// comes from below (walls get the average of the two, so a darker ground colour shades the walls). It only cares
// whether a face points up or down, so on its own every side of a building, or of a spinning cube, looks the same.
// LIGHT_LEVEL is the total light that roofs and streets get: 3.14 (pi) shows them exactly as painted. (It was 3.4
// with the film curve.) The sun takes its share of it and the hemisphere light supplies the rest, so changing the
// sun never makes roofs and streets brighter or darker.
const LIGHT_SKY_COLOUR = 0xffffff;
const LIGHT_GROUND_COLOUR = 0xdddddd;
const LIGHT_LEVEL = 3.14;

// The sun: a light that comes from one direction, so faces turned towards it are brighter than faces turned away.
// That gives buildings a lit side and a shaded side, and makes the orange cubes change shade as they spin.
// SUN_LEVEL 0 switches it off (every side then looks the same). Around 1 to 1.5 is gentle, 2 or more is strong.
// SUN_ELEVATION is how high it is, in degrees (0 = on the horizon, 90 = straight overhead). A low sun puts more of
// its light on walls and less on roofs. SUN_AZIMUTH is which way it is, in degrees: 0 = in front of you at the
// start, 90 = to your right, 180 = behind you, 270 = to your left.
// SUN_OPPOSITE adds a second sun on the opposite side of the sky (same colour and level), so a wall or a spinning
// cube is shaded all the way round. With one sun, everything turned away from it is equally dark. With two suns,
// avoid an azimuth of 45, 135, 225 or 315: all four walls of a building are then lit equally.
const SUN_COLOUR = 0xffffff;
const SUN_LEVEL = 1;
const SUN_ELEVATION = 30;
const SUN_AZIMUTH = 20;
const SUN_OPPOSITE = true;

// --- Tone mapping ---
// THREE.NoToneMapping shows colours exactly as painted. THREE.ACESFilmicToneMapping is the old "film" look: it
// darkens darks and pales brights (use LIGHT_LEVEL 3.4 with it), and it suits an HDRI sky better.
const TONE_MAPPING = THREE.NoToneMapping;

// --- Sky: a gradient from the colour overhead (top) to the colour at the horizon and below (horizon) ---
// The sky is scenery only: it does not light the buildings.
// Use the same colour twice for a flat sky. Add your own themes to the list.

export const SKY_THEMES = {
    buttercream: { top: 0xfff3c6, horizon: 0xe6bd72 },
    apricot:     { top: 0xffe6cc, horizon: 0xf0a868 },
    peachfizz:   { top: 0xffe0d4, horizon: 0xee9a86 },
    coralreef:   { top: 0xffe4e1, horizon: 0xfc9c94 },
    rose:        { top: 0xfee3e6, horizon: 0xfb9aa9 },
    blossom:     { top: 0xfde2ec, horizon: 0xdc8fae },
    orchid:      { top: 0xfde1f9, horizon: 0xe49ede },
    lavenderpop: { top: 0xf0e0fa, horizon: 0xb48bd8 },
    lagoon:      { top: 0xcaf4f6, horizon: 0x44d0d7 },
    sandstone:   { top: 0xf7ecd9, horizon: 0xcfae85 },
    periwinkle:  { top: 0xe4e9fc, horizon: 0x849af8 },
};

// export const SKY_THEMES = {
    // dustBlue:       { top: 0xbdd0e6, horizon: 0x4f6b8f },
    // peachDusk:      { top: 0xf2cfb8, horizon: 0x8a6478 },
    // lilacMist:      { top: 0xd6cae6, horizon: 0x6a5f93 },
    // sageMorning:    { top: 0xd0ddc8, horizon: 0x66806f },
    // seaGlass:       { top: 0xc3dedb, horizon: 0x3f6b73 },
    // roseSmoke:      { top: 0xe8c6cd, horizon: 0x7a5870 },
    // pearlGrey:      { top: 0xe6e1dc, horizon: 0x6b6b78 },
    // strawHaze:      { top: 0xf0e0b8, horizon: 0x8a7a60 },
    // twilightIndigo: { top: 0xb4c0e2, horizon: 0x4f5f9c },
    // oliveHaze:      { top: 0xe0e6c0, horizon: 0x6c7a4a },
// };

// export const SKY_THEMES = {
    // pandora:   { top: 0x004060, horizon: 0xC8D8E8 },
    // day:       { top: 0xdbe8f5, horizon: 0x3b78c8 },
    // overcast:  { top: 0xdadfe6, horizon: 0x5a6470 },
    // sunset:    { top: 0xff9a7a, horizon: 0x2b2a6e },
    // retroDusk: { top: 0x14143f, horizon: 0xdcdce4 },
    // neon:      { top: 0xff3fa4, horizon: 0x0b0638 },
    // candy:     { top: 0xffc4e4, horizon: 0x9a7bff },
    // mint:      { top: 0xcffff0, horizon: 0x145a64 },
    // night:     { top: 0x2a3c72, horizon: 0x03040c },
    // arcade:    { top: 0x9dff6a, horizon: 0x04170d },
// };

// export const SKY_THEMES = {
    // pandora:   { top: 0xC8D8E8, horizon: 0x004060 },
    // day:       { top: 0x3b78c8, horizon: 0xdbe8f5 },
    // overcast:  { top: 0x5a6470, horizon: 0xdadfe6 },
    // sunset:    { top: 0x2b2a6e, horizon: 0xff9a7a },
    // retroDusk: { top: 0xdcdce4, horizon: 0x14143f },
    // neon:      { top: 0x0b0638, horizon: 0xff3fa4 },
    // candy:     { top: 0x9a7bff, horizon: 0xffc4e4 },
    // mint:      { top: 0x145a64, horizon: 0xcffff0 },
    // night:     { top: 0x03040c, horizon: 0x2a3c72 },
    // arcade:    { top: 0x04170d, horizon: 0x9dff6a },
// };
// SKY_THEME is the sky the game starts with: 'random' (a different one every game: every theme is used once before
// any comes round again, and the same one never comes up twice in a row), or the name of one theme to always start with.
const SKY_THEME = 'random';
// SKY_CHANGES_AT_GALLERIES: true = a new random sky every time a gallery is revealed. false = the sky stays as it is.
const SKY_CHANGES_AT_GALLERIES = true;
// SKY_FADE_SECONDS: how long a change from one sky to the next takes (0 = at once).
const SKY_FADE_SECONDS = 2.5;

// --- Sky image (an HDRI): only for trying out skies. While USE_HDRI_SKY is false nothing is downloaded. ---
// When it is true, the gradient sky shows first and the image replaces it once it has downloaded (about 17 MB);
// the sky themes above then no longer show.
// Without the film curve, bright clouds can look blown out: lower HDRI_BRIGHTNESS, or switch the film curve on.
const USE_HDRI_SKY = false;
const HDRI_FILE = 'https://dl.polyhaven.org/file/ph-assets/HDRIs/hdr/4k/kloppenheim_06_puresky_4k.hdr';
const HDRI_BRIGHTNESS = 1.0;

export function setupScene() {
    const scene = new THREE.Scene();

    // The sky: which theme to start with, and how it changes later. The bag hands out the themes in random order,
    // using them all up before any repeats and never the same one twice in a row.
    const themeNames = Object.keys(SKY_THEMES);
    const bag = createShuffleBag(themeNames);
    let pinned = null;                     // the one theme every game starts with, or null when it is 'random'
    if (SKY_THEME !== 'random') {
        pinned = themeNames.includes(SKY_THEME) ? SKY_THEME : themeNames[0];
        if (pinned !== SKY_THEME) console.warn(`[sky] SKY_THEME "${SKY_THEME}" is not 'random' or in SKY_THEMES, so "${pinned}" is used. The themes are: ${themeNames.join(', ')}.`);
    }
    let skyName = pinned ?? bag.next();
    const sky = createSky(scene, SKY_THEMES[skyName]);
    console.info(`[sky] gradient "${skyName}"`);
    const randomOther = () => { let name; do { name = bag.next(); } while (name === skyName && themeNames.length > 1); return name; };
    const changeSky = (name) => { skyName = name; sky.setTheme(SKY_THEMES[name], SKY_FADE_SECONDS); console.info(`[sky] changing to "${name}"`); };
    const skyControl = {
        get theme() { return skyName; },
        /** A gallery was just revealed: change to a new random sky (if SKY_CHANGES_AT_GALLERIES is on). */
        next() { if (SKY_CHANGES_AT_GALLERIES) changeSky(randomOther()); },
        /** A new game is starting (Play Again): a new random sky, or the pinned one again. */
        restart() { const name = pinned ?? randomOther(); if (name !== skyName) changeSky(name); },
    };

    // Each sun gives roofs and streets SUN_LEVEL x sin(elevation) of their light; the hemisphere light supplies the rest.
    const elevation = SUN_ELEVATION * Math.PI / 180;
    const sunAzimuths = SUN_LEVEL <= 0 ? [] : SUN_OPPOSITE ? [SUN_AZIMUTH, SUN_AZIMUTH + 180] : [SUN_AZIMUTH];
    const sunOnRoofs = sunAzimuths.length * SUN_LEVEL * Math.sin(elevation);
    if (sunOnRoofs > LIGHT_LEVEL) console.warn(`[light] the sun light (SUN_LEVEL ${SUN_LEVEL}${sunAzimuths.length > 1 ? ' each' : ''}) is stronger than LIGHT_LEVEL ${LIGHT_LEVEL} on roofs and streets, so the hemisphere light is switched off. Lower SUN_LEVEL or raise LIGHT_LEVEL.`);

    const hemisphereLight = new THREE.HemisphereLight(LIGHT_SKY_COLOUR, LIGHT_GROUND_COLOUR, Math.max(0, LIGHT_LEVEL - sunOnRoofs));
    hemisphereLight.position.set(0, 50, 0);
    scene.add(hemisphereLight);

    for (const degrees of sunAzimuths) {
        const azimuth = degrees * Math.PI / 180;
        const sun = new THREE.DirectionalLight(SUN_COLOUR, SUN_LEVEL);
        sun.position.set(100 * Math.sin(azimuth) * Math.cos(elevation), 100 * Math.sin(elevation), -100 * Math.cos(azimuth) * Math.cos(elevation));
        scene.add(sun);
    }

    if (USE_HDRI_SKY) {
        new HDRLoader().load(HDRI_FILE, (texture) => {
            texture.mapping = THREE.EquirectangularReflectionMapping;
            scene.background = texture;
            scene.backgroundIntensity = HDRI_BRIGHTNESS;
            sky.mesh.visible = false;     // the gradient sky is hidden behind the image
        }, undefined, (error) => {
            console.warn('The sky image could not be loaded, so the gradient sky stays.', error);
        });
    }

    const camera = new THREE.PerspectiveCamera(65, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(SPAWN.x, FLOOR_Y, SPAWN.z);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = TONE_MAPPING;
    renderer.toneMappingExposure = 1.0;
    document.body.appendChild(renderer.domElement);

    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });

    return { scene, camera, renderer, sky: skyControl };
}
