// shapes.js: the special shapes ("floaters"): what each lowercase letter in a level file means.
// Pure data and logic (no THREE, no DOM), and it imports nothing, so every other module can use it.
//
// THE MINI-LANGUAGE (how a shape is written): the first digit builds storeys from the ground up, then
// "+n" adds a cube at storey n and "-n" removes storey n. Storey 1 is the ground floor; one storey is 5 m.
//   0+3  nothing on the ground, one cube at storey 3: a bridge with 10 m open below
//   3-1  a 3-storey building with its ground floor removed: a gate you walk through
//   3-2  a 3-storey wall with storey 2 removed: a window you climb through
//
// THE RULES (see floater-dictionary.md, "plan A"):
//   1. Letters are grouped in families by geometry. Only ACTIVE letters may be used in a level; a letter
//      that is not active (or not in the table, like s-z today) is refused. Since v1.6 all 18 of plan A are active.
//   2. A letter used in a saved map is FROZEN: its meaning never changes again
//      (tests/unit/shapes.test.mjs keeps the list and fails if one changes).
//   3. No two letters mean the same storeys, and no letter means the same as a plain digit building.

export const MAX_STOREY = 9;

// family: a-h single floaters, i-l connected doubles, m-o one-gap doubles, p-r ground plus floater, s-z free
export const SHAPES = Object.freeze({
    a: { written: '0+2',   active: true , name: 'low bridge (5 m open below: you bump your head jumping under it)' },
    b: { written: '0+3',   active: true,  name: 'bridge (10 m open below)' },
    c: { written: '0+4',   active: true , name: 'high bridge (15 m open below)' },
    d: { written: '0+5',   active: true , name: 'single floater at storey 5' },
    e: { written: '0+6',   active: true , name: 'single floater at storey 6' },
    f: { written: '0+7',   active: true , name: 'single floater at storey 7' },
    g: { written: '0+8',   active: true , name: 'single floater at storey 8' },
    h: { written: '0+9',   active: true , name: 'single floater at storey 9' },
    i: { written: '3-1',   active: true,  name: 'gate: a tunnel through a 3-storey building (5 m open below)' },
    j: { written: '0+3+4', active: true , name: 'viaduct: a thick bridge (10 m open below)' },
    k: { written: '0+4+5', active: true , name: 'connected double at storeys 4-5' },
    l: { written: '0+5+6', active: true , name: 'connected double at storeys 5-6' },
    m: { written: '0+2+4', active: true , name: 'two tiers: storeys 2 and 4' },
    n: { written: '0+3+5', active: true , name: 'two tiers: storeys 3 and 5' },
    o: { written: '0+4+6', active: true , name: 'two tiers: storeys 4 and 6 (the plan A pagoda ring)' },
    p: { written: '3-2',   active: true,  name: 'window wall: a 5 m sill, an opening at storey 2, a lintel at storey 3' },
    q: { written: '1+4',   active: true , name: 'ground storey plus a floater at storey 4' },
    r: { written: '2+4',   active: true , name: 'two ground storeys plus a floater at storey 4' },
});

/**
 * Turn a written shape ("0+3", "3-1", "3-2") into its solid storeys, lowest first: [3], [2, 3], [1, 3].
 * Throws with a clear message for anything that is not a sound shape.
 */
export function parseShape(written) {
    const m = /^([0-9])((?:[+-][1-9])*)$/.exec(String(written));
    if (!m) throw new Error(`"${written}" is not a shape: write a digit, then any number of +n or -n (n from 1 to 9).`);
    const solid = new Set();
    for (let s = 1; s <= Number(m[1]); s++) solid.add(s);
    for (const [, sign, digit] of m[2].matchAll(/([+-])([1-9])/g)) {
        const n = Number(digit);
        if (sign === '+') {
            if (solid.has(n)) throw new Error(`"${written}": storey ${n} is already solid, so +${n} adds nothing.`);
            solid.add(n);
        } else {
            if (!solid.has(n)) throw new Error(`"${written}": storey ${n} is not solid, so -${n} removes nothing.`);
            solid.delete(n);
        }
    }
    if (solid.size === 0) throw new Error(`"${written}" has no solid storey at all.`);
    return [...solid].sort((x, y) => x - y);
}

// The solid storeys of every letter, worked out once (the table is fixed, so a broken entry fails at load).
const STOREYS = Object.freeze(Object.fromEntries(
    Object.entries(SHAPES).map(([letter, s]) => [letter, Object.freeze(parseShape(s.written))])));

/** True if `code` is a letter that a level may use now (an active shape). */
export function isActiveShape(code) {
    return Object.prototype.hasOwnProperty.call(SHAPES, code) && SHAPES[code].active;
}

/** The solid storeys of an active shape letter, lowest first (b gives [3]), or null for anything else. */
export function shapeStoreys(code) {
    return isActiveShape(code) ? STOREYS[code] : null;
}

/** The solid storeys of any letter in the table, active or reserved (for tests and tools), or null. */
export function plannedStoreys(code) {
    return Object.prototype.hasOwnProperty.call(STOREYS, code) ? STOREYS[code] : null;
}

/** The letters a level may use now, in order (since v1.6: a to r). */
export const ACTIVE_LETTERS = Object.freeze(Object.keys(SHAPES).filter(isActiveShape));
