// shuffleBag.js: hand out items in random order, using up the whole pile before any repeat.
// Used by builder.js (the order of the plazas) and gallery.js (the order of the posters).

/** Fisher-Yates shuffle, in place. Returns the same array. */
export function shuffleInPlace(arr, rng = Math.random) {
    for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(rng() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
}

/**
 * A "smart" shuffle bag: one continuous loop of shuffled piles.
 *   - Every item is handed out once before any item comes round again.
 *   - When the pile runs out it is reshuffled, and the new pile never STARTS with the item the old
 *     pile ENDED on, so the same item never comes up twice in a row across the boundary.
 *   - The very first item is random.
 * The bag keeps its place for as long as you keep it, so create it once and reuse it.
 *
 * @param {Array} items  what to hand out (at least one)
 * @param {() => number} [rng=Math.random]  random source; pass a seeded one in tests
 * @returns {{ next: () => any }}
 */
export function createShuffleBag(items, rng = Math.random) {
    if (!items || items.length === 0) throw new Error('createShuffleBag: needs at least one item');
    let pile = [];
    let last;
    let hasLast = false;

    function refill() {
        pile = shuffleInPlace([...items], rng);
        // Items are taken from the END of the pile (pop). If that would repeat the last item handed
        // out, swap in a different one. With a single distinct item there is nothing else to use.
        if (hasLast && pile[pile.length - 1] === last) {
            const others = [];
            for (let k = 0; k < pile.length - 1; k++) if (pile[k] !== last) others.push(k);
            if (others.length > 0) {
                const k = others[Math.floor(rng() * others.length)];
                [pile[k], pile[pile.length - 1]] = [pile[pile.length - 1], pile[k]];
            }
        }
    }

    return {
        next() {
            if (pile.length === 0) refill();
            last = pile.pop();
            hasLast = true;
            return last;
        },
    };
}
