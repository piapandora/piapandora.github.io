// sky.js: the gradient sky. A big sphere around the camera whose colour at every pixel is worked out from the
// direction you are looking, so there is no picture to stretch and no seam. It can fade smoothly from one pair of
// colours to another. The sky is scenery only: it does not light anything.
// (A trimmed version of the standalone sky.js: no drifting colours and no sun.)
import * as THREE from 'three';

// Where the gradient runs, as the height of the view direction (-1 straight down, 0 the horizon, 1 straight up):
// the horizon colour holds up to just under the horizon, and the top colour is reached about 49 degrees up.
const GRADIENT_FROM = -0.05, GRADIENT_TO = 0.75;

export const VERTEX_SHADER = `
    varying vec3 vDir;
    void main() {
        vDir = position;
        // the view without its position: the sky is always centred on the camera, however far you walk or climb
        gl_Position = projectionMatrix * vec4(mat3(viewMatrix) * position, 1.0);
    }`;

// The colours are mixed and written as they are (like a CSS gradient), with no tone mapping.
export const FRAGMENT_SHADER = `
    uniform vec3 uTop;
    uniform vec3 uHorizon;
    uniform vec2 uRange;
    varying vec3 vDir;
    void main() {
        vec3 d = normalize(vDir);
        float k = smoothstep(uRange.x, uRange.y, d.y);
        gl_FragColor = vec4(mix(uHorizon, uTop, k), 1.0);
        // tiny noise so 8-bit gradients do not show banding lines
        gl_FragColor.rgb += (fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453) - 0.5) / 255.0;
    }`;

const rgb = (hex) => new THREE.Vector3(((hex >> 16) & 255) / 255, ((hex >> 8) & 255) / 255, (hex & 255) / 255);
const ease = (t) => t * t * (3 - 2 * t);

/**
 * @param {THREE.Scene} scene
 * @param {{ top: number, horizon: number }} theme  the colours to start with, as hex numbers
 * @param {{ now?: () => number }} [options]  a clock in milliseconds (tests pass their own)
 * @returns {{ mesh, update(dt), setTheme(theme, seconds), dispose() }}
 */
export function createSky(scene, theme, options = {}) {
    const now = options.now ?? (() => performance.now());
    const uniforms = { uTop: { value: rgb(theme.top) }, uHorizon: { value: rgb(theme.horizon) }, uRange: { value: new THREE.Vector2(GRADIENT_FROM, GRADIENT_TO) } };
    const material = new THREE.ShaderMaterial({ uniforms, vertexShader: VERTEX_SHADER, fragmentShader: FRAGMENT_SHADER, side: THREE.BackSide, depthWrite: false, depthTest: false, fog: false });
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(500, 32, 16), material);
    mesh.renderOrder = -1000;       // drawn first, behind everything
    mesh.frustumCulled = false;     // always drawn
    scene.add(mesh);

    let fade = null;                // the change in progress, if any
    function update(dt) {
        if (!fade) return;
        fade.t = Math.min(1, fade.t + dt / fade.seconds);
        const k = ease(fade.t);
        uniforms.uTop.value.lerpVectors(fade.fromTop, fade.toTop, k);
        uniforms.uHorizon.value.lerpVectors(fade.fromHorizon, fade.toHorizon, k);
        if (fade.t >= 1) fade = null;
    }

    // Three.js calls this just before it draws the sky each frame, so the fade needs nothing from the game loop.
    // A long gap (for example a hidden tab) only counts as 0.1 s, so the fade is never skipped.
    let last = now();
    mesh.onBeforeRender = () => {
        const t = now();
        update(Math.min(0.1, Math.max(0, (t - last) / 1000)));
        last = t;
    };

    return {
        mesh,
        update,
        /** Change to a new pair of colours, smoothly over `seconds` (0 = at once). A change in progress is not lost: the new one starts from the colours showing now. */
        setTheme(next, seconds = 2.5) {
            if (!(seconds > 0)) {
                uniforms.uTop.value.copy(rgb(next.top));
                uniforms.uHorizon.value.copy(rgb(next.horizon));
                fade = null;
                return;
            }
            fade = { t: 0, seconds, fromTop: uniforms.uTop.value.clone(), fromHorizon: uniforms.uHorizon.value.clone(), toTop: rgb(next.top), toHorizon: rgb(next.horizon) };
        },
        dispose() {
            scene.remove(mesh);
            mesh.geometry.dispose();
            material.dispose();
        },
    };
}
