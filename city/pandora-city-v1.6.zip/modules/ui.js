// ui.js: everything that touches the page's HUD, toasts and overlay screens.
// Game logic stays in main.js; it calls these functions instead of poking the DOM.
// Elements are looked up once at import (module scripts run after the page is parsed).

const instructions     = document.getElementById('instructions');
const winScreen        = document.getElementById('win-screen');
const restartBtn       = document.getElementById('restart-btn');
const continueBtn      = document.getElementById('continue-btn');
const scoreBoard       = document.getElementById('score-board');
const scoreElement     = document.getElementById('score');
const targetDisplay    = document.getElementById('target-display');
const winTargetDisplay = document.getElementById('win-target-display');
const posterToast      = document.getElementById('poster-notification');
const hintToast        = document.getElementById('hint-notification');
const mapToast         = document.getElementById('map-notification');
const mapToastText     = document.getElementById('map-notification-text');

// --- HUD ---
// the small version label at the bottom of the start screen
const versionLabel = document.getElementById('version-label');
export function setVersion(text) { if (versionLabel) versionLabel.textContent = text; }

export function setTarget(n) {
    targetDisplay.textContent = n;
    winTargetDisplay.textContent = n;
}
export function setScore(n) { scoreElement.textContent = n; }
export function setScoreboardVisible(visible) { scoreBoard.style.display = visible ? 'block' : 'none'; }

// --- instructions overlay ---
export function showInstructions() { instructions.style.display = 'block'; }
export function hideInstructions() { instructions.style.display = 'none'; }

// --- the "game has not started yet" box in index.html: main.js removes it once the game is running ---
export function hideBootMessage() { document.getElementById('boot-error')?.remove(); }

// --- win screen (fades in/out via the .show class) ---
export function isWinScreenVisible() { return winScreen.classList.contains('show'); }
export function showWinScreen() {
    winScreen.style.display = 'block';
    setTimeout(() => winScreen.classList.add('show'), 50);
}
export function hideWinScreen() {
    winScreen.classList.remove('show');
    setTimeout(() => { winScreen.style.display = 'none'; }, 1000);
}

// --- toasts: restart the CSS animation each time ---
function replayToast(el) {
    el.classList.remove('poster-slide');
    void el.offsetWidth;                 // force a reflow so the animation can restart
    el.classList.add('poster-slide');
}
export function showPosterToast() { replayToast(posterToast); }
export function showHintToast()   { replayToast(hintToast); }
export function showMapSavedToast(fileName) {
    mapToastText.textContent = `Map saved: ${fileName}`;
    replayToast(mapToast);
}

// --- save a text file to the player's computer (it lands in their Downloads folder) ---
export function downloadTextFile(fileName, text, mimeType = 'text/csv;charset=utf-8') {
    const url = URL.createObjectURL(new Blob([text], { type: mimeType }));
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// --- input hooks: main.js decides what each click does ---
export function onInstructionsClick(fn) { instructions.addEventListener('click', fn); }
export function onRestart(fn)           { restartBtn.addEventListener('click', fn); }
export function onContinue(fn)          { continueBtn.addEventListener('click', fn); }