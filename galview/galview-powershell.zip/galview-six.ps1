# galview.ps1
# Powershell version of GalView image array builder with multi-directory support

# Prompt for image directories
$inputDirs = Read-Host "Enter one or more full paths to folders containing images (comma separated)"

# Split input on commas, trim spaces
$dirs = $inputDirs -split ',' | ForEach-Object { $_.Trim() }

# Initialize array to store image paths
$imagePaths = @()

foreach ($dir in $dirs) {
    if (-Not (Test-Path $dir)) {
        Write-Host "WARNING: Directory '$dir' does not exist. Skipping..."
        continue
    }

    # Get image files (case-insensitive)
    $files = Get-ChildItem -Path $dir -File | Where-Object {
        $_.Extension -match '^(?i)\.png|\.jpg|\.jpeg|\.webp|\.gif|\.bmp$'
    }

    if ($files.Count -eq 0) {
        Write-Host "INFO: No images found in '$dir'. Skipping..."
        continue
    }

    foreach ($file in $files) {
        # Use full path and convert backslashes for web
        $webPath = ($file.FullName -replace '\\','/')
        $imagePaths += '"' + $webPath + '"'
    }
}

if ($imagePaths.Count -eq 0) {
    Write-Host "No images found in any of the specified directories. Exiting."
    exit
}

# Set HTML and JS files
$jsFile = Join-Path $PSScriptRoot "images.js"
$htmlFile = Join-Path $PSScriptRoot "galview-six.html"

# Build JS array
$imgJS = "const images = [" + ($imagePaths -join ",") + "];"

# Write to images.js
$imgJS | Out-File -FilePath $jsFile -Encoding UTF8

Write-Host "Successfully created images.js with $($imagePaths.Count) images."

# Launch HTML
if (Test-Path $htmlFile) {
    Write-Host "Launching GalView..."
    Start-Process $htmlFile
} else {
    Write-Host "HTML file not found at '$htmlFile'. Please ensure galview-six.html exists."
}

exit
